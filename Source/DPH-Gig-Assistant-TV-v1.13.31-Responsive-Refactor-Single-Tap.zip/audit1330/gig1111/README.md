DPH Gig Assistant TV v1.10.0 — optional Performance Mode toggle.

## Version 1.10.0 — Performance Mode button
- Added a Performance ON/OFF button to the playback control strip.
- Performance Mode presents the current song title more prominently, shows the next song (or LAST SONG IN SET), and enlarges playback status text.
- Standard playback status remains available by switching Performance Mode OFF.
- TV remote: during playback, press UP to focus Speak, then DOWN to focus Performance; OK toggles the selected button. LEFT/RIGHT still adjust speed while either button has focus.
- Version code 43.

DPH Gig Assistant TV v1.9.6 — fixes the missing `speechRecognizer` property declaration that caused Kotlin unresolved-reference errors in MainActivity.kt.

# DPH Gig Assistant — Android TV and Phone

## Version 1.9.4 — Voice recognition compatibility fix
- Push-to-talk now launches Android's standard speech-recognition activity instead of depending on a directly available SpeechRecognizer service.
- The first tap on Speak requests the app's microphone permission; if granted, speech recognition starts immediately.
- Recognition results are routed into the existing voice-command handler, with clearer feedback when recognition is cancelled or unavailable.
- Added common spoken variations for next/skip, previous/back, resume, restart, and text-size commands.
- Existing setlist, lyrics, playback, and dark-and-gold UI features are retained.


This Android Studio project is an Android TV port of Gig_Assistant, branded **DPH Gig Assistant**.

## Latest update (version 1.4)
- Increased home title and file-browser heading space to prevent clipped/squashed text.
- Increased file/folder row height and spacing; long names can wrap to two lines.
- Added a high-contrast yellow focus state for TV remote navigation, with selected files shown in green when not focused.
- Changed the browser action to **PLAY SELECTED (n)**. Selecting this starts the chosen file or queue directly, without an additional confirmation dialog.
- Fixed long lyric text being clipped to the initial viewport by measuring the complete text height; font-size changes remeasure the full lyrics so scrolling continues through the whole song.
- Countdown screen now starts with the **Start now** button visibly focused; remote arrow keys navigate the action buttons instead of changing teleprompter settings.
- Version 1.4; keeps Java/Kotlin JVM target 17 compatibility.

## Build
Open the `GigAssistantTV` folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This is an initial implementation and should be tested on the target Xiaomi Mi Box.
- USB storage access depends on the Android version and how the USB volume is mounted. If the device blocks direct path access, the browser may need to use Android's Storage Access Framework instead.
- Text files are expected to be UTF-8 `.txt` files.


## v1.4.2 queue behavior fix
- Start now cancels and invalidates the countdown before starting the selected next song, preventing a stale timer from immediately advancing again.
- Skip file skips only the displayed upcoming song and presents a fresh countdown for the following song, instead of starting it automatically.
- Cancel queue stops the countdown and exits the queue.


## v1.4.4 app icon and browser focus fix
- Added a custom dark charcoal-and-gold **DPH Gig Assistant** launcher icon at Android launcher densities and set the installed app name to **DPH Gig Assistant**.
- When selecting or deselecting a `.txt` file, the browser now remembers the current scroll position and restores focus to that same file, so you can continue down the list without jumping back to the top.
- Version 1.4.4 (version code 7).


## v1.4.6 visual polish and input fixes
- Expanded the lyric-screen footer to 104dp and adjusted text size, spacing, and wording so both status and remote-control lines have room.
- Updated home/file-browser button styling to a charcoal-and-gold palette with clearer focus and selected states.
- Selecting the seconds-between-songs input now selects the existing value automatically, so typing replaces it without backspacing.
- App version is 1.4.6; application ID remains unchanged for in-place upgrades.


## v1.6.8 single-song practice repeat
- When exactly one lyric file is selected, the app asks whether to **Repeat until BACK** or **Play once**.
- Repeat mode restarts the lyrics continuously for song-learning practice; pressing BACK exits playback to file selection.
- Play once returns to the file browser after the lyrics finish.
- Multi-song queue behavior and existing TV banner/launcher artwork are unchanged.


## Version 1.9.2
- Applies the DPH dark navy, white, and gold visual theme to standard Android dialogs and pop-outs.
- Adds a dark rounded dialog surface with a subtle gold border, white primary text, muted secondary text, and gold action buttons/focus accents.
- Carries forward the v1.9.1 focus-following and editable setlist/online connection features.
- Build version: 1.9.2 (version code 37).


## v1.9.3 — Phone-ready push-to-talk voice controls
- Added a push-to-talk microphone button to the lyrics performance screen.
- Added voice commands for next/previous song, pause/resume, restart, faster/slower, larger/smaller text, repeat, stop, and asking what song is next.
- Added runtime microphone permission handling and visible feedback for recognized or unrecognized commands.
- Removed the forced landscape orientation so the app can launch on Android phones as well as Android TV.
- This is the first phone-control step only; phone-to-TV companion control is a later phase.
- ZIP integrity checked; compilation and device testing still need to be performed in Android Studio/on devices.


## Version 1.9.5 — Push-to-talk voice recognition fix
- Uses Android `SpeechRecognizer` directly instead of launching the external speech-recognition Activity, which can route users to Google Assistant and return “Sorry, I can't do this on this app.”
- Requests microphone permission when Speak is tapped and starts recognition after permission is granted.
- Adds clearer error messages for unavailable recognition services, microphone permission, network errors, and no-match results.
- Cleans up the speech recognizer when the Activity is destroyed.


## Version 1.9.7 — TV remote microphone navigation
- In the lyrics viewer, press D-pad UP to focus the yellow Speak button.
- Press OK/Enter to activate in-app push-to-talk.
- The focused microphone has a brighter, high-contrast highlight.
- Directional controls continue to adjust speed/font after leaving microphone focus.
- Existing BACK/MENU and playback behavior is retained.

## Version 1.11.2
- Made the single-song repeat/play-once prompt cancelable, including an explicit Cancel button and BACK dismissal. Cancel leaves the user on the screen they came from and does not start playback.
- Organized the Home screen into collapsible sections: Your Library & Setlists, Pro Features & Upgrade, and Settings & Help. Browse and Select Lyrics remains prominent at the top.
- Preserved the v1.11.1 setlist duplication/recent-history implementation and the v1.11.0 Free/Pro, voice, Performance Mode, and per-song settings functionality.


## v1.13.0 changes

- Phone remote buttons now visibly highlight the last button tapped, instead of leaving Pause/Resume highlighted.
- Added JSON backup export/import under Home → Settings & Help. Backups include saved setlists, song/setlist notes, recent history, online lyric locations, per-song playback settings, and local Free/Pro test-tier settings. Import replaces those app preference datasets after confirmation.
- This is a development/testing build; validate backup/restore on a test backup before relying on it.
