package com.gravelunion.gigassistanttv

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.FileProvider
import android.content.ContentValues
import android.speech.RecognizerIntent
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Environment
import android.Manifest
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.util.TypedValue
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import android.database.Cursor
import android.provider.OpenableColumns
import android.provider.MediaStore
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.ServerSocket
import java.net.Socket
import java.net.InetAddress
import java.net.NetworkInterface
import java.io.BufferedInputStream
import java.io.OutputStream
import java.util.concurrent.atomic.AtomicBoolean
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private val backupPreferenceNames = listOf("online_lyrics_locations", "saved_setlists", "recent_play_history", "per_song_playback_settings", "gig_assistant_notes", "gig_assistant_entitlements")
    private data class Song(val uri: Uri, val name: String, val text: String)

    private val handler = Handler(Looper.getMainLooper())
    private val speedSteps = doubleArrayOf(0.02, 0.04, 0.06, 0.08, 0.10, 0.15, 0.20, 0.30, 0.40, 0.50, 0.65, 0.80, 1.00, 1.50, 2.00, 3.00, 5.00, 8.00, 10.00)
    private var speedIndex = 12
    private var fontSp = 32f
    private var paused = false
    private var scrollYFloat = 0f
    private var scrollAccumulator = 0.0
    private var scrollText: TextView? = null
    private var viewport: FrameLayout? = null
    private var status: TextView? = null
    private var currentSongIndex = 0
    private var currentSetlistName: String? = null
    private var queue = mutableListOf<Song>()
    private var queueDelaySeconds = 30
    private var countdown = 0
    // Invalidates any queued countdown tick when a button is pressed.
    private var countdownGeneration = 0
    private var inViewer = false
    private var inBrowser = false
    private var inSavedSetlists = false
    private var inRecentHistory = false
    private var inOnlineLyrics = false
    private var onlineRootUrl: String? = null
    private var onlineCurrentApiUrl: String? = null
    private var onlineCurrentRawBase: String? = null
    private var onlineCurrentPath = ""
    private val onlineSelected = linkedMapOf<String, Song>()
    private val onlineUseSelectedButtons = mutableListOf<Button>()
    private val onlinePrefs by lazy { getSharedPreferences("online_lyrics_locations", Context.MODE_PRIVATE) }
    private var lastBackPressAt = 0L
    private var isCountdownScreen = false
    private var isQueueMode = false
    // When exactly one lyric file is selected, the user chooses whether to loop it.
    private var repeatSingleSongUntilBack = false
    private var repeatCurrentSong = false
    private var voiceStatusMessage: String? = null
    // Holds the active Android speech-recognition session used by push-to-talk.
    private var speechRecognizer: SpeechRecognizer? = null
    private var voiceButton: Button? = null
    private var performanceButton: Button? = null
    // When a modal review dialog is open, route phone navigation into that dialog
    // rather than accidentally moving focus on the screen underneath it.
    private var remoteNavigationRoot: View? = null
    private var remoteNavigationDialog: AlertDialog? = null
    private var performanceModeEnabled = false
    // Optional phone remote: only listens on the local network while the user enables it.
    private var remoteServerSocket: ServerSocket? = null
    private var remoteServerThread: Thread? = null
    private val remoteServerRunning = AtomicBoolean(false)
    private val remotePort = 8765
    // Distinguish a short OK press (pause/resume) from a long OK press (voice input).
    private var okLongPressTriggered = false
    private var okPressPending = false
    private val okLongPressRunnable = Runnable {
        if (okPressPending && inViewer && voiceButton?.hasFocus() != true && performanceButton?.hasFocus() != true) {
            // A long OK press opens the footer navigation rather than immediately
            // starting speech recognition. This gives reliable access to both
            // Speak and Performance ON/OFF while keeping a short OK as pause/resume.
            okLongPressTriggered = true
            okPressPending = false
            voiceButton?.requestFocus()
        }
    }
    private var endHandled = false
    private var lastTick = 0L
    private var browserDirectory: java.io.File? = null
    private val selectedFilePaths = linkedSetOf<String>()
    private var browserMessage: String? = null
    // Keep the file-browser viewport and highlighted file when the list is rebuilt after a selection.
    private var browserFocusedPath: String? = null
    private var browserScrollY = 0
    private var lastLoadedQueue = mutableListOf<Song>()
    private val setlistPrefs by lazy { getSharedPreferences("saved_setlists", Context.MODE_PRIVATE) }
    private val historyPrefs by lazy { getSharedPreferences("recent_play_history", Context.MODE_PRIVATE) }
    private val songSettingsPrefs by lazy { getSharedPreferences("per_song_playback_settings", Context.MODE_PRIVATE) }
    private val notesPrefs by lazy { getSharedPreferences("gig_assistant_notes", Context.MODE_PRIVATE) }
    // Centralized Free/Pro entitlement foundation. Billing is intentionally not wired yet.
    private val entitlementPrefs by lazy { getSharedPreferences("gig_assistant_entitlements", Context.MODE_PRIVATE) }
    private enum class ProFeature { PER_SONG_SETTINGS, PERFORMANCE_MODE, SONG_NOTES, SETLIST_NOTES, FUTURE_SETLIST_TOOLS }
    // This development build actively simulates Free/Pro so both experiences can be tested.
    // Replace the testing tier with verified Google Play entitlement before release.
    private val enforceProEntitlements = true

    private fun isProEntitled(): Boolean {
        // An explicit test-tier choice takes precedence so Simulate Free always works.
        val testingTier = entitlementPrefs.getString("testing_tier", null)
        return if (testingTier != null) testingTier == "pro"
        else entitlementPrefs.getBoolean("pro_entitled", false)
    }

    private fun hasProFeatureAccess(feature: ProFeature): Boolean {
        if (!enforceProEntitlements) return true
        return when (feature) {
            ProFeature.PER_SONG_SETTINGS, ProFeature.PERFORMANCE_MODE, ProFeature.SONG_NOTES, ProFeature.SETLIST_NOTES, ProFeature.FUTURE_SETLIST_TOOLS -> isProEntitled()
        }
    }

    private fun showProFeatureRequired(featureName: String) {
        AlertDialog.Builder(this)
            .setTitle("Gig Assistant Pro")
            .setMessage("$featureName is a Gig Assistant Pro feature.\n\nChoose Gig Assistant Pro on the Home screen to preview the Free and Pro tiers. Purchases are not enabled in this development build.")
            .setPositiveButton("View Free / Pro", null)
            .setNegativeButton("Not now", null)
            .showWithPhoneRemote()
    }

    // Apply a final, device-aware pass to every screen after it is assembled.
    // This catches legacy screens whose individual controls still have fixed sizes.
    override fun setContentView(view: View) {
        super.setContentView(view)
        view.post { applyAdaptiveLayout(view) }
    }

    private fun applyAdaptiveLayout(root: View) {
        val compact = isCompactScreen
        val targetButtonHeight = dp(if (compact) 52 else 68)
        val minText = if (compact) 11 else 14
        val maxText = if (compact) 16 else 19

        fun visit(node: View) {
            if (node is Button) {
                node.includeFontPadding = true
                node.isFocusable = true
                // Touch devices should activate on the first tap; D-pad focus remains
                // enabled on TV. Focus-in-touch-mode can make legacy focus handling
                // feel like a first-tap-to-focus / second-tap-to-activate interaction.
                node.isFocusableInTouchMode = !compact
                node.maxLines = 2
                node.ellipsize = android.text.TextUtils.TruncateAt.END
                node.gravity = Gravity.CENTER
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    node.setAutoSizeTextTypeUniformWithConfiguration(
                        minText, maxText, 1, TypedValue.COMPLEX_UNIT_SP
                    )
                }
                node.minimumHeight = targetButtonHeight
                node.minHeight = targetButtonHeight
                val lp = node.layoutParams
                if (lp != null && lp.height >= 0 && lp.height < targetButtonHeight) {
                    lp.height = targetButtonHeight
                    node.layoutParams = lp
                }
                if (compact) {
                    val horizontal = dp(8)
                    node.setPadding(horizontal, dp(6), horizontal, dp(6))
                }
            }
            if (node is ViewGroup) {
                // Legacy rows with four or more controls cannot remain side-by-side
                // on a narrow phone. Stack their controls instead of shrinking labels
                // until they become unreadable or clipped.
                if (compact && node is LinearLayout && node.orientation == LinearLayout.HORIZONTAL) {
                    val buttonChildren = (0 until node.childCount).count { node.getChildAt(it) is Button }
                    if (buttonChildren >= 4 && node.width in 1..dp(520)) {
                        node.orientation = LinearLayout.VERTICAL
                        for (i in 0 until node.childCount) {
                            val child = node.getChildAt(i)
                            val childLp = child.layoutParams
                            if (childLp is LinearLayout.LayoutParams) {
                                childLp.width = ViewGroup.LayoutParams.MATCH_PARENT
                                if (child is Button) childLp.height = targetButtonHeight
                                childLp.weight = 0f
                                childLp.bottomMargin = dp(5)
                                child.layoutParams = childLp
                            }
                        }
                    }
                }
                for (i in 0 until node.childCount) visit(node.getChildAt(i))
            }
        }
        visit(root)
    }

    // Responsive layout profile: preserve the generous TV controls, but use a
    // compact touch-friendly profile on phones and narrow windows. The profile
    // follows the available screen configuration and therefore also adapts on rotation.
    private val isCompactScreen: Boolean
        get() = resources.configuration.smallestScreenWidthDp < 600

    // Scale dimensions against the actual available window width, not a fixed
    // phone/TV assumption. smallestScreenWidthDp identifies the device class;
    // screenWidthDp lets the layout respond to rotation, split-screen and TV sizes.
    private val adaptiveScale: Float
        get() {
            val width = resources.configuration.screenWidthDp.coerceAtLeast(280)
            val reference = if (isCompactScreen) 390f else 960f
            val raw = width / reference
            return if (isCompactScreen) raw.coerceIn(0.82f, 1.12f)
                   else raw.coerceIn(0.82f, 1.08f)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun responsiveDp(tvValue: Int, phoneValue: Int): Int {
        val base = if (isCompactScreen) phoneValue else tvValue
        return dp((base * adaptiveScale).toInt().coerceAtLeast(1))
    }

    private fun displaySongName(fileName: String): String {
        // URI path segments are percent-encoded (for example, spaces appear as %20).
        // Decode for display only; stored URIs remain unchanged.
        val readableName = Uri.decode(fileName)
        return if (readableName.substringAfterLast('.', "").equals("txt", true)) {
            readableName.substringBeforeLast('.')
        } else readableName
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!inViewer) return
            val vp = viewport ?: return
            val text = scrollText ?: return
            if (!paused) {
                val now = System.nanoTime()
                val dt = if (lastTick == 0L) 16L else ((now - lastTick) / 1_000_000L).coerceIn(1L, 50L)
                lastTick = now
                scrollAccumulator += speedSteps[speedIndex] * (dt / 16.0)
                val pixels = scrollAccumulator.toInt()
                if (pixels > 0) {
                    scrollAccumulator -= pixels
                    scrollYFloat -= pixels
                    text.translationY = scrollYFloat
                }
                if (!endHandled && scrollYFloat < -(text.height + 100f)) {
                    endHandled = true
                    if (repeatCurrentSong) {
                        scrollYFloat = vp.height + 20f
                        scrollAccumulator = 0.0
                        endHandled = false
                        text.translationY = scrollYFloat
                        updateStatus()
                    } else if (isQueueMode) {
                        handler.post { startIntermissionOrNext() }
                        return
                    } else if (queue.size == 1 && repeatSingleSongUntilBack) {
                        // Practice mode: restart the lyrics continuously until BACK is pressed.
                        scrollYFloat = vp.height + 20f
                        scrollAccumulator = 0.0
                        endHandled = false
                        text.translationY = scrollYFloat
                        updateStatus()
                    } else {
                        // Single-play mode: stop after the lyrics have passed once.
                        handler.removeCallbacks(this)
                        inViewer = false
                        browserMessage = "Song finished. Select a song to play again."
                        showFileBrowser()
                        return
                    }
                }
            } else {
                lastTick = System.nanoTime()
            }
            handler.postDelayed(this, 16L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        if (resources.configuration.smallestScreenWidthDp >= 600) enterImmersive()
        // Pro users enter playback with Performance Mode enabled by default.
        // Free users continue to start with the standard lyric display.
        performanceModeEnabled = isProEntitled()
        showHome()
    }

    private fun enterImmersive() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    private fun verticalLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(responsiveDp(40, 14), responsiveDp(30, 12), responsiveDp(40, 14), responsiveDp(30, 12))
        setBackgroundColor(Color.rgb(10, 14, 20))
    }

    private fun makeText(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    // Shared visual styling: polish button consistency without changing actions,
    // navigation, focus order, or the existing screen layouts.
    private fun buttonSurface(fill: Int, stroke: Int = Color.rgb(73, 84, 99)): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), stroke)
        }

    private fun styleButton(button: Button) {
        // Shared control baseline used throughout the app. Individual screens may set
        // their own height or alignment to fit their content, but the visual language
        // (shape, typography, default surface, focus treatment) stays consistent.
        button.textSize = (if (isCompactScreen) 15f else 18f) * adaptiveScale.coerceIn(0.88f, 1.0f)
        button.minimumWidth = if (isCompactScreen) 0 else responsiveDp(120, 0)
        button.includeFontPadding = true
        button.gravity = Gravity.CENTER
        button.minHeight = responsiveDp(68, 48)
        button.minimumHeight = responsiveDp(68, 48)
        if (isCompactScreen && android.os.Build.VERSION.SDK_INT >= 26) {
            button.setAutoSizeTextTypeUniformWithConfiguration(12, 16, 1, android.util.TypedValue.COMPLEX_UNIT_SP)
        }
        button.maxLines = if (isCompactScreen) 2 else 2
        button.ellipsize = android.text.TextUtils.TruncateAt.END
        button.isAllCaps = false
        button.isFocusable = true
        button.isFocusableInTouchMode = !isCompactScreen
        button.setPadding(responsiveDp(18, 9), responsiveDp(10, 6), responsiveDp(18, 9), responsiveDp(10, 6))
        button.setTextColor(Color.rgb(242, 245, 249))
        button.background = buttonSurface(Color.rgb(25, 33, 44))
        button.elevation = 0f
        // Gold is reserved for the active focus state, with dark text for contrast.
        button.setOnFocusChangeListener { view, hasFocus ->
            val focusedButton = view as Button
            if (hasFocus) {
                focusedButton.background = buttonSurface(Color.rgb(255, 202, 32), Color.rgb(255, 225, 105))
                focusedButton.setTextColor(Color.rgb(15, 19, 25))
                focusedButton.elevation = dp(2).toFloat()
            } else {
                focusedButton.background = buttonSurface(Color.rgb(25, 33, 44))
                focusedButton.setTextColor(Color.rgb(242, 245, 249))
                focusedButton.elevation = 0f
            }
        }
    }

    private data class AppRelease(val version: String, val title: String, val notes: String, val apkUrl: String, val apkName: String)
    private var updateBlinker: Runnable? = null
    private var updateAvailableButton: Button? = null
    private var updateBlinkOn = false

    private fun versionParts(value: String): List<Int> =
        Regex("\\d+").findAll(value).mapNotNull { it.value.toIntOrNull() }.toList()

    private fun isNewerVersion(remote: String, installed: String): Boolean {
        val a = versionParts(remote)
        val b = versionParts(installed)
        if (a.isEmpty() || b.isEmpty()) return remote != installed
        for (i in 0 until max(a.size, b.size)) {
            val av = a.getOrElse(i) { 0 }
            val bv = b.getOrElse(i) { 0 }
            if (av != bv) return av > bv
        }
        return false
    }

    private fun checkForAppUpdate() {
        val progressDialog = AlertDialog.Builder(this)
            .setTitle("Check for Updates")
            .setMessage("Checking GitHub for the latest published Gig Assistant release…")
            .setCancelable(false)
            .showWithPhoneRemote()
        Thread {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL("https://api.github.com/repos/huberdph/DPH-GA/releases/latest").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15000
                    readTimeout = 15000
                    setRequestProperty("Accept", "application/vnd.github+json")
                    setRequestProperty("User-Agent", "DPH-Gig-Assistant-TV")
                }
                if (connection.responseCode !in 200..299) throw Exception("GitHub returned HTTP ${connection.responseCode}.")
                val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                if (json.optBoolean("draft", false) || json.optBoolean("prerelease", false)) throw Exception("The latest GitHub release is marked as a draft or pre-release. Publish a regular release with an APK asset.")
                val assets = json.optJSONArray("assets") ?: JSONArray()
                val apks = (0 until assets.length()).mapNotNull { assets.optJSONObject(it) }
                    .filter { it.optString("name").endsWith(".apk", true) && it.optString("browser_download_url").startsWith("https://") }
                if (apks.isEmpty()) throw Exception("The latest published release does not contain an APK file yet.")
                val asset = apks.first()
                val version = json.optString("tag_name", json.optString("name", "")).removePrefix("v").removePrefix("V")
                if (version.isBlank()) throw Exception("The release does not have a version tag.")
                val release = AppRelease(version, json.optString("name", "Gig Assistant $version"), json.optString("body", ""), asset.getString("browser_download_url"), asset.getString("name"))
                val installed = packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
                runOnUiThread {
                    if (isFinishing) return@runOnUiThread
                    progressDialog.dismiss()
                    if (isNewerVersion(release.version, installed)) showUpdateAvailable(release, installed)
                    else AlertDialog.Builder(this).setTitle("Gig Assistant Is Up to Date")
                        .setMessage("Installed version: $installed\nLatest release: ${release.version}\n\nNo update is needed.")
                        .setPositiveButton("OK", null).showWithPhoneRemote()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (isFinishing) return@runOnUiThread
                    progressDialog.dismiss()
                    AlertDialog.Builder(this).setTitle("Update Check Failed")
                        .setMessage("${e.message ?: "Unable to check GitHub."}\n\nCheck your internet connection and confirm that the repository has a published release containing an APK.")
                        .setPositiveButton("OK", null).showWithPhoneRemote()
                }
            } finally { connection?.disconnect() }
        }.start()
    }

    private fun showUpdateAvailable(release: AppRelease, installed: String) {
        updateAvailableButton?.text = "⚠  UPDATE AVAILABLE  •  ${release.version}"
        updateBlinker?.let { handler.removeCallbacks(it) }
        updateBlinkOn = false
        val blink = object : Runnable {
            override fun run() {
                val button = updateAvailableButton ?: return
                updateBlinkOn = !updateBlinkOn
                button.text = if (updateBlinkOn) "⚠  UPDATE AVAILABLE  •  ${release.version}" else "UPDATE AVAILABLE  •  ${release.version}"
                button.setTextColor(if (updateBlinkOn) Color.rgb(255, 205, 35) else Color.WHITE)
                button.background = buttonSurface(if (updateBlinkOn) Color.rgb(55, 43, 15) else Color.rgb(25, 33, 44), Color.rgb(255, 205, 35))
                handler.postDelayed(this, 750)
            }
        }
        updateBlinker = blink
        handler.post(blink)
        val notes = release.notes.take(1200).ifBlank { "No release notes were provided." }
        AlertDialog.Builder(this)
            .setTitle("UPDATE AVAILABLE — ${release.version}")
            .setMessage("Installed version: $installed\nLatest version: ${release.version}\nAPK: ${release.apkName}\n\n$notes")
            .setNegativeButton("Later", null)
            .setPositiveButton("Download & Install") { _, _ -> downloadAndInstallUpdate(release) }
            .showWithPhoneRemote()
    }

    private fun downloadAndInstallUpdate(release: AppRelease) {
        val dialog = AlertDialog.Builder(this).setTitle("Downloading Update")
            .setMessage("Downloading ${release.apkName}…\nPlease keep Gig Assistant open.")
            .setCancelable(false).create()
        // This is an AlertDialog instance (created above), not a Builder.
        // Show it directly; the Builder-only showWithPhoneRemote extension cannot apply here.
        dialog.show()
        Thread {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(release.apkUrl).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = true
                    connectTimeout = 20000
                    readTimeout = 30000
                    setRequestProperty("User-Agent", "DPH-Gig-Assistant-TV")
                }
                if (connection.responseCode !in 200..299) throw Exception("Download failed with HTTP ${connection.responseCode}.")
                val file = java.io.File(cacheDir, "gig-assistant-update.apk")
                connection.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                if (file.length() < 100_000) throw Exception("The downloaded APK appears incomplete or invalid.")
                runOnUiThread {
                    dialog.dismiss()
                    installDownloadedApk(file)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dialog.dismiss()
                    AlertDialog.Builder(this).setTitle("Download Failed")
                        .setMessage(e.message ?: "Unable to download the update.")
                        .setPositiveButton("OK", null).showWithPhoneRemote()
                }
            } finally { connection?.disconnect() }
        }.start()
    }

    private fun installDownloadedApk(file: java.io.File) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
                AlertDialog.Builder(this).setTitle("Allow App Installation")
                    .setMessage("Android needs permission to install updates downloaded from GitHub. Enable ‘Allow from this source’ for Gig Assistant, then return and choose Check for App Updates again.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Open Settings") { _, _ ->
                        startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:$packageName")))
                    }.showWithPhoneRemote()
                return
            }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle("Could Not Start Installer")
                .setMessage("${e.message ?: "Android could not open the APK installer."}\n\nMake sure the APK was signed with the same signing key as the installed app.")
                .setPositiveButton("OK", null).showWithPhoneRemote()
        }
    }

    private fun localIpv4Address(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val network = interfaces.nextElement()
                if (!network.isUp || network.isLoopback) continue
                val addresses = network.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (address is java.net.Inet4Address && !address.isLoopbackAddress && !address.isLinkLocalAddress) {
                        return address.hostAddress
                    }
                }
            }
            null
        } catch (_: Exception) { null }
    }

    private fun showPhoneRemote() {
        val gold = Color.rgb(255, 202, 32)
        val muted = Color.rgb(175, 184, 196)
        val root = verticalLayout()
        root.setPadding(dp(28), dp(22), dp(28), dp(22))
        root.addView(makeText("PHONE REMOTE CONTROL", 25f, gold, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(makeText("Use your phone as a wireless controller for Gig Assistant on this TV. Your phone and TV must be connected to the same Wi-Fi network.", 17f, Color.WHITE), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        val address = localIpv4Address()
        val url = if (address != null) "http://$address:$remotePort" else "IP address not available"
        val addressText = makeText(if (remoteServerRunning.get()) "REMOTE IS ON\n$url" else "REMOTE IS OFF\n$url", 22f, if (remoteServerRunning.get()) gold else Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setPadding(dp(12), dp(18), dp(12), dp(18))
            background = buttonSurface(Color.rgb(20, 27, 37), gold)
        }
        root.addView(addressText, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        root.addView(makeText("On your phone, open the address above in a browser. Keep this screen open while enabling the remote. Anyone on your local network who knows this address may be able to control playback, so turn it off when you are finished.", 15f, muted), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
        lateinit var toggle: Button
        toggle = Button(this).apply {
            text = if (remoteServerRunning.get()) "Turn Phone Remote OFF" else "Turn Phone Remote ON"
            styleButton(this); textSize = 18f
            setOnClickListener {
                if (remoteServerRunning.get()) stopPhoneRemoteServer() else startPhoneRemoteServer()
                addressText.text = if (remoteServerRunning.get()) "REMOTE IS ON\n$url" else "REMOTE IS OFF\n$url"
                toggle.text = if (remoteServerRunning.get()) "Turn Phone Remote OFF" else "Turn Phone Remote ON"
            }
        }
        root.addView(toggle, LinearLayout.LayoutParams(-1, responsiveDp(58, 46)).apply { bottomMargin = dp(8) })
        val back = Button(this).apply { text = "Back to Home"; styleButton(this); textSize = 18f; setOnClickListener { showHome() } }
        root.addView(back, LinearLayout.LayoutParams(-1, responsiveDp(58, 46)))
        setContentView(root)
        toggle.requestFocus()
    }

    private fun startPhoneRemoteServer() {
        if (remoteServerRunning.get()) return
        try {
            val server = ServerSocket(remotePort, 8, InetAddress.getByName("0.0.0.0"))
            remoteServerSocket = server
            remoteServerRunning.set(true)
            remoteServerThread = Thread {
                while (remoteServerRunning.get()) {
                    try {
                        val client = server.accept()
                        Thread { handleRemoteClient(client) }.start()
                    } catch (_: Exception) {
                        if (remoteServerRunning.get()) continue else break
                    }
                }
            }.apply { name = "GigAssistantPhoneRemote"; isDaemon = true; start() }
            Toast.makeText(this, "Phone remote enabled on port $remotePort", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            remoteServerRunning.set(false)
            Toast.makeText(this, "Could not start phone remote: ${e.message ?: "port unavailable"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopPhoneRemoteServer() {
        remoteServerRunning.set(false)
        try { remoteServerSocket?.close() } catch (_: Exception) { }
        remoteServerSocket = null
        remoteServerThread = null
        Toast.makeText(this, "Phone remote disabled", Toast.LENGTH_SHORT).show()
    }

    private fun handleRemoteClient(client: Socket) {
        client.use { socket ->
            socket.soTimeout = 2500
            val input = BufferedInputStream(socket.getInputStream())
            val reader = input.bufferedReader(Charsets.UTF_8)
            val requestLine = reader.readLine() ?: return
            // Consume remaining request headers before responding.
            while (true) { val line = reader.readLine() ?: break; if (line.isEmpty()) break }
            val path = requestLine.split(" ").getOrNull(1)?.substringBefore('?') ?: "/"
            val query = requestLine.split(" ").getOrNull(1)?.substringAfter('?', "") ?: ""
            val response: String
            val contentType: String
            when {
                path == "/" -> { response = phoneRemoteHtml(); contentType = "text/html; charset=utf-8" }
                path == "/api/state" -> { response = remoteStateJson(); contentType = "application/json; charset=utf-8" }
                path == "/action" -> {
                    val params = query.split('&').mapNotNull { part ->
                        val pair = part.split('=', limit = 2)
                        if (pair.size == 2) pair[0] to pair[1] else null
                    }.toMap()
                    val action = params["do"]?.let { URLDecoder.decode(it, "UTF-8") }.orEmpty()
                    val value = params["value"]?.let { URLDecoder.decode(it, "UTF-8") }.orEmpty()
                    handler.post { performRemoteAction(action, value) }
                    response = "{\"ok\":true}"; contentType = "application/json; charset=utf-8"
                }
                else -> { response = "Not found"; contentType = "text/plain; charset=utf-8" }
            }
            val bytes = response.toByteArray(Charsets.UTF_8)
            val header = "HTTP/1.1 ${if (path.startsWith("/api/") || path == "/action" || path == "/") "200 OK" else "404 Not Found"}\r\nContent-Type: $contentType\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\nCache-Control: no-store\r\nAccess-Control-Allow-Origin: *\r\n\r\n"
            socket.getOutputStream().apply { write(header.toByteArray(Charsets.UTF_8)); write(bytes); flush() }
        }
    }

    private fun remoteStateJson(): String {
        val song = queue.getOrNull(currentSongIndex)?.name.orEmpty()
        val next = queue.getOrNull(currentSongIndex + 1)?.name.orEmpty()
        return JSONObject().put("enabled", remoteServerRunning.get()).put("active", inViewer)
            .put("paused", paused).put("song", song).put("next", next)
            .put("position", if (queue.isEmpty()) 0 else currentSongIndex + 1).put("total", queue.size)
            .put("speed", String.format(Locale.US, "%.2f", speedSteps[speedIndex]))
            .put("font", fontSp.toInt()).put("performance", performanceModeEnabled).toString()
    }

    /** Shows an AlertDialog and routes phone-remote navigation into that modal window. */
    private fun AlertDialog.Builder.showWithPhoneRemote(): AlertDialog {
        val previousDialog = remoteNavigationDialog
        val previousRoot = remoteNavigationRoot
        val dialog = create()
        dialog.setOnDismissListener {
            if (remoteNavigationDialog === dialog) {
                if (previousDialog != null && previousDialog.isShowing) {
                    remoteNavigationDialog = previousDialog
                    remoteNavigationRoot = previousDialog.window?.decorView
                } else {
                    remoteNavigationDialog = null
                    remoteNavigationRoot = previousRoot?.takeIf { previousRoot.isShown }
                }
            }
        }
        dialog.setOnShowListener {
            remoteNavigationDialog = dialog
            remoteNavigationRoot = dialog.window?.decorView
            val root = remoteNavigationRoot
            if (root != null) {
                // Apply to every field, including fields pre-populated before the dialog opens.
                applyRemoteKeyboardPolicy(root)
                // Prefer an editable field for typing dialogs; otherwise focus the first
                // available button/control so phone Select always has a meaningful target.
                val input = findFirstEditText(root)
                // When the phone remote is enabled, text is entered from the phone.
                // Prevent Android TV from opening its own on-screen keyboard whenever
                // a text field is focused in an editing dialog.
                if (input != null && remoteServerRunning.get()) {
                    input.showSoftInputOnFocus = false
                    input.setOnFocusChangeListener { view, hasFocus ->
                        if (hasFocus) {
                            (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
                                ?.hideSoftInputFromWindow(view.windowToken, 0)
                        }
                    }
                }
                val target = input ?: findFirstFocusable(root)
                target?.post {
                    target.requestFocus()
                    if (input != null && remoteServerRunning.get()) {
                        (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
                            ?.hideSoftInputFromWindow(input.windowToken, 0)
                    }
                }
            }
        }
        dialog.show()
        // Set immediately as well as in onShow, avoiding a short window where a rapid
        // phone command could still be routed to the Activity behind the popup.
        remoteNavigationDialog = dialog
        remoteNavigationRoot = dialog.window?.decorView
        return dialog
    }

    /** Enforce the active input policy on every text field in a dialog. When Phone Remote is
     * enabled, the phone is the only keyboard; otherwise native TV keyboard input is allowed.
     */
    private fun applyRemoteKeyboardPolicy(view: View) {
        if (view is EditText && remoteServerRunning.get()) {
            view.showSoftInputOnFocus = false
            (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
                ?.hideSoftInputFromWindow(view.windowToken, 0)
        }
        if (view is android.view.ViewGroup) {
            for (index in 0 until view.childCount) applyRemoteKeyboardPolicy(view.getChildAt(index))
        }
    }

    private fun findFirstEditText(view: View): EditText? {
        if (view is EditText && view.isShown && view.isFocusable) return view
        if (view is android.view.ViewGroup) {
            for (index in 0 until view.childCount) {
                findFirstEditText(view.getChildAt(index))?.let { return it }
            }
        }
        return null
    }

    private fun findFirstFocusable(view: View): View? {
        if (view.isShown && view.isFocusable && view.isEnabled) return view
        if (view is android.view.ViewGroup) {
            for (index in 0 until view.childCount) {
                findFirstFocusable(view.getChildAt(index))?.let { return it }
            }
        }
        return null
    }

    private fun isViewWithin(view: View, root: View): Boolean {
        var current: View? = view
        while (current != null) {
            if (current === root) return true
            current = current.parent as? View
        }
        return false
    }

    private fun performRemoteAction(action: String, value: String = "") {
        // Phone-based text entry avoids relying on Android TV's separate system IME
        // window, which cannot receive navigation consistently from a web remote.
        if (action == "text" || action == "backspace" || action == "cleartext") {
            val navigationRoot = remoteNavigationRoot ?: window.decorView
            val input = (navigationRoot.findFocus() as? EditText)
                ?: currentFocus?.takeIf { it is EditText && isViewWithin(it, navigationRoot) } as? EditText
                ?: findFirstEditText(navigationRoot)
            if (input != null) {
                input.requestFocus()
                val start = input.selectionStart.coerceAtLeast(0)
                val end = input.selectionEnd.coerceAtLeast(0)
                val editable = input.text
                when (action) {
                    "text" -> {
                        editable.replace(minOf(start, end), maxOf(start, end), value)
                        input.setSelection((minOf(start, end) + value.length).coerceAtMost(editable.length))
                    }
                    "backspace" -> {
                        if (start != end) editable.delete(minOf(start, end), maxOf(start, end))
                        else if (start > 0) editable.delete(start - 1, start)
                        input.setSelection((if (start != end) minOf(start, end) else (start - 1).coerceAtLeast(0)).coerceAtMost(editable.length))
                    }
                    "cleartext" -> { editable.clear(); input.setSelection(0) }
                }
            } else {
                Toast.makeText(this, "Select a text field on the TV first.", Toast.LENGTH_SHORT).show()
            }
            return
        }
        // The phone remote can also navigate the currently visible TV screen.
        // This is useful for screens such as Home, Browse Files, and the Start Now
        // countdown where the user needs to move focus and activate a highlighted button.
        if (action == "up" || action == "down" || action == "left" || action == "right") {
            val navigationRoot = remoteNavigationRoot ?: window.decorView
            val focused = navigationRoot.findFocus()
                ?: currentFocus?.takeIf { isViewWithin(it, navigationRoot) }
            val direction = when (action) {
                "up" -> View.FOCUS_UP
                "down" -> View.FOCUS_DOWN
                "left" -> View.FOCUS_LEFT
                else -> View.FOCUS_RIGHT
            }
            val nextFocus = focused?.focusSearch(direction)
            if (nextFocus != null && isViewWithin(nextFocus, navigationRoot)) {
                nextFocus.requestFocus()
            } else if (focused == null) {
                navigationRoot.requestFocus()
            }
            return
        }
        if (action == "select") {
            val navigationRoot = remoteNavigationRoot ?: window.decorView
            val focused = navigationRoot.findFocus()
                ?: currentFocus?.takeIf { isViewWithin(it, navigationRoot) }
            if (focused is EditText) {
                // Select on an EditText commits its current value instead of re-opening
                // an on-screen keyboard. Phone Text Entry can then supply any correction.
                if (focused === delayInputRef) {
                    queueDelaySeconds = focused.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 30
                    focused.clearFocus()
                    val next = focused.focusSearch(View.FOCUS_DOWN)
                    if (next != null && isViewWithin(next, navigationRoot)) next.requestFocus()
                    Toast.makeText(this, "Delay set to ${queueDelaySeconds}s", Toast.LENGTH_SHORT).show()
                } else {
                    focused.performClick()
                }
            } else if (focused != null && focused.isFocusable) {
                if (!focused.performClick()) {
                    focused.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_CENTER))
                    focused.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DPAD_CENTER))
                }
            } else {
                navigationRoot.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_CENTER))
                navigationRoot.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DPAD_CENTER))
            }
            return
        }
        if (action == "navback") {
            val dialog = remoteNavigationDialog
            if (dialog != null && dialog.isShowing) {
                dialog.cancel()
            } else {
                // No modal screen is active; return to the app's Home screen.
                if (inViewer) {
                    remoteNavigationRoot = null
                    showHome("Playback stopped.")
                } else {
                    showHome()
                }
            }
            return
        }
        if (action == "home") { handler.removeCallbacks(tick); remoteNavigationRoot = null; remoteNavigationDialog = null; showHome("Playback stopped."); return }
        if (action == "speak") {
            if (inViewer) voiceButton?.performClick()
            else voiceStatusMessage = "Open a song on the TV before using Speak from the phone remote."
            return
        }
        if (!inViewer) { voiceStatusMessage = "Use the phone remote's directional and Select controls to navigate the TV screen."; return }
        when (action) {
            "pause" -> paused = true
            "play" -> { paused = false; lastTick = System.nanoTime() }
            "toggle" -> { paused = !paused; lastTick = System.nanoTime() }
            "next" -> if (currentSongIndex < queue.lastIndex) { currentSongIndex++; playCurrent() }
                else { handler.removeCallbacks(tick); showHome("Queue finished."); return }
            "previous" -> {
                if (currentSongIndex > 0) {
                    currentSongIndex--
                    playCurrent()
                    voiceStatusMessage = "Previous song: ${queue.getOrNull(currentSongIndex)?.name.orEmpty()}"
                } else {
                    restartCurrentSong()
                    voiceStatusMessage = "Already at the first song; restarting it."
                }
            }
            "back" -> showNextAfterManualBack()
            "faster" -> changeSpeed(1)
            "slower" -> changeSpeed(-1)
            "fontup" -> changeFont(2f)
            "fontdown" -> changeFont(-2f)
            "restart" -> restartCurrentSong()
            "performance" -> {
                if (hasProFeatureAccess(ProFeature.PERFORMANCE_MODE)) {
                    performanceModeEnabled = !performanceModeEnabled
                    performanceButton?.text = if (performanceModeEnabled) "Performance ON" else "Performance OFF"
                }
            }
        }
        updateStatus()
    }

    private fun phoneRemoteHtml(): String = """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"><meta name="theme-color" content="#0a0e14"><title>Gig Assistant Remote</title><style>
*{box-sizing:border-box}body{margin:0;background:#0a0e14;color:#f2f5f9;font-family:system-ui,Arial,sans-serif;padding:18px}header{text-align:center;margin:4px 0 18px}h1{font-size:28px;margin:0;color:#ffca20}header div{color:#aeb8c4;letter-spacing:2px;font-size:11px;margin-top:5px}.card{background:#151d27;border:1px solid #394657;border-radius:14px;padding:16px;margin:12px 0}.label{font-size:12px;color:#ffca20;font-weight:700;letter-spacing:1px}.song{font-size:22px;font-weight:700;overflow-wrap:anywhere;margin:8px 0}.sub{color:#aeb8c4;font-size:14px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px}.navpad{display:grid;grid-template-columns:1fr 1fr 1fr;grid-template-rows:auto auto auto;gap:10px;margin:12px 0;align-items:stretch}.navpad button{min-height:54px;font-size:17px}.navpad .empty{visibility:hidden;pointer-events:none}button{border:1px solid #ffca20;border-radius:12px;background:#242b35;color:#fff;font-size:18px;font-weight:650;min-height:58px;padding:12px 8px;touch-action:manipulation}button.primary{background:#242b35;color:#fff}button.selected{background:#ffca20!important;color:#10141a!important;box-shadow:0 0 0 2px #fff inset}button:focus-visible{outline:3px solid #fff;outline-offset:2px}.wide{width:100%;margin-top:10px}.small{font-size:15px;min-height:48px}.status{font-size:14px;color:#aeb8c4;text-align:center;margin:12px 0}</style></head><body><header><h1>Gig Assistant</h1><div>YOUR SETLIST. YOUR STAGE.</div></header><section class="card"><div class="label">NOW PLAYING</div><div class="song" id="song">Connect to TV…</div><div class="sub" id="details">Waiting for playback status</div><div class="label" style="margin-top:14px">UP NEXT</div><div id="next" class="sub">—</div></section><section class="card" style="padding:12px"><div class="label">TV SCREEN NAVIGATION</div><div class="navpad"><span class="empty" style="grid-column:1;grid-row:1" aria-hidden="true"></span><button class="small" style="grid-column:2;grid-row:1" onclick="act('up',this)" aria-label="Move focus up">▲ Up</button><span class="empty" style="grid-column:3;grid-row:1" aria-hidden="true"></span><button class="small" style="grid-column:1;grid-row:2" onclick="act('left',this)" aria-label="Move focus left">◀ Left</button><button class="small" style="grid-column:2;grid-row:2" onclick="act('select',this)">Select / OK</button><button class="small" style="grid-column:3;grid-row:2" onclick="act('right',this)" aria-label="Move focus right">Right ▶</button><span class="empty" style="grid-column:1;grid-row:3" aria-hidden="true"></span><button class="small" style="grid-column:2;grid-row:3" onclick="act('down',this)" aria-label="Move focus down">▼ Down</button><button class="small" style="grid-column:3;grid-row:3" onclick="act('navback',this)" aria-label="Go back">↩ Back</button></div><div class="sub">Use the directional buttons to move the TV highlight, then Select / OK to activate the focused item.</div><div class="label" style="margin-top:14px">PHONE TEXT ENTRY</div><div class="sub">Select a text field on the TV, then type here to enter text without navigating the TV's system keyboard.</div><div style="display:grid;grid-template-columns:1fr auto;gap:8px;margin-top:8px"><input id="remoteText" type="text" autocomplete="off" placeholder="Type setlist name or seconds…" style="min-width:0;width:100%;background:#0a0e14;color:#fff;border:1px solid #667384;border-radius:10px;padding:12px;font-size:16px"><button class="small" onclick="sendText()">Send</button></div><div class="grid" style="margin-top:8px"><button class="small" onclick="act('backspace',this)">⌫ Backspace</button><button class="small" onclick="act('cleartext',this)">Clear Field</button></div></section><div class="grid"><button onclick="act('toggle',this)" id="pause">Pause / Resume</button><button onclick="act('restart',this)">Restart Song</button><button onclick="act('previous',this)">◀ Previous</button><button onclick="act('next',this)">Next ▶</button><button onclick="act('slower',this)">Slower</button><button onclick="act('faster',this)">Faster</button><button onclick="act('fontdown',this)">A− Smaller Text</button><button onclick="act('fontup',this)">A+ Bigger Text</button><button class="small" onclick="act('speak',this)">🎙 Speak</button><button class="small" onclick="act('performance',this)">Performance Mode</button><button class="small" onclick="act('back',this)">Back / Next Up</button><button class="small" onclick="act('home',this)">Stop / Home</button></div><div id="status" class="status">Connecting…</div><script>
async function act(a,btn){document.querySelectorAll('button.selected').forEach(b=>b.classList.remove('selected'));if(btn)btn.classList.add('selected');try{await fetch('/action?do='+encodeURIComponent(a),{cache:'no-store'});setTimeout(refresh,180)}catch(e){document.getElementById('status').textContent='Connection lost. Check that phone and TV are on the same Wi-Fi.'}}async function sendText(){const el=document.getElementById('remoteText');if(!el.value)return;try{await fetch('/action?do=text&value='+encodeURIComponent(el.value),{cache:'no-store'});el.value='';document.getElementById('status').textContent='Text sent to the focused TV field.'}catch(e){document.getElementById('status').textContent='Could not send text to TV.'}}async function refresh(){try{let r=await fetch('/api/state',{cache:'no-store'});let s=await r.json();document.getElementById('song').textContent=s.active?s.song:'No song playing on TV';document.getElementById('next').textContent=s.next||'Last song in set';document.getElementById('details').textContent=s.active?(s.paused?'PAUSED':'PLAYING')+' · '+s.position+'/'+s.total+' · Speed '+s.speed+' · Font '+s.font:'Start playback on the TV to use controls';document.getElementById('pause').textContent=s.paused?'Resume':'Pause';document.getElementById('status').textContent='Connected to Gig Assistant TV'+(s.performance?' · Performance Mode ON':'')}catch(e){document.getElementById('status').textContent='Cannot reach TV. Confirm same Wi-Fi and that Phone Remote is ON.'}}refresh();setInterval(refresh,1200)</script></body></html>"""

    private fun startBackupExport() {
        try {
            val fileName = "GigAssistant-Backup-${java.text.SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(java.util.Date())}.json"
            val json = buildBackupJson().toString(2)
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("Android could not create the backup in Downloads.")
                contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(json) }
                    ?: error("Could not write the backup file.")
                Toast.makeText(this, "Backup saved to Downloads/$fileName", Toast.LENGTH_LONG).show()
            } else {
                val folder = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
                if (!folder.exists()) folder.mkdirs()
                java.io.File(folder, fileName).writeText(json, Charsets.UTF_8)
                Toast.makeText(this, "Backup saved in app Downloads: ${folder.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle("Backup Export Failed")
                .setMessage(e.message ?: "Could not export the backup.")
                .setPositiveButton("OK", null).showWithPhoneRemote()
        }
    }

    private fun confirmBackupImport() {
        AlertDialog.Builder(this)
            .setTitle("Import Backup")
            .setMessage("Importing a backup replaces the saved Gig Assistant setlists, notes, history, and settings on this device. Export a backup first if you want to preserve the current data. Continue?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Choose Backup") { _, _ -> chooseBackupFromDownloads() }
            .showWithPhoneRemote()
    }

    private fun chooseBackupFromDownloads() {
        try {
            val backups = mutableListOf<Pair<String, Uri>>()
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                contentResolver.query(collection, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns._ID),
                    "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?", arrayOf("GigAssistant-Backup%.json"),
                    "${MediaStore.MediaColumns.DATE_MODIFIED} DESC")?.use { cursor ->
                    val nameIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                    val idIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                    while (cursor.moveToNext()) {
                        val name = cursor.getString(nameIndex) ?: continue
                        val id = cursor.getLong(idIndex)
                        backups.add(name to Uri.withAppendedPath(collection, id.toString()))
                    }
                }
            } else {
                val folder = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
                folder.listFiles { file -> file.isFile && file.name.startsWith("GigAssistant-Backup") && file.name.endsWith(".json") }
                    ?.sortedByDescending { it.lastModified() }?.forEach { backups.add(it.name to Uri.fromFile(it)) }
            }
            if (backups.isEmpty()) {
                AlertDialog.Builder(this).setTitle("No Backups Found")
                    .setMessage("No GigAssistant-Backup JSON files were found in Downloads. Export a backup on this device first, or copy a backup file into the TV's Downloads folder.")
                    .setPositiveButton("OK", null).showWithPhoneRemote()
                return
            }
            AlertDialog.Builder(this).setTitle("Choose a Backup")
                .setItems(backups.map { it.first }.toTypedArray()) { _, which -> importBackupUri(backups[which].second) }
                .setNegativeButton("Cancel", null).showWithPhoneRemote()
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle("Backup Import Failed")
                .setMessage(e.message ?: "Could not list backup files in Downloads.")
                .setPositiveButton("OK", null).showWithPhoneRemote()
        }
    }

    private fun importBackupUri(uri: Uri) {
        try {
            val text = if (uri.scheme == "file") java.io.File(uri.path!!).readText(Charsets.UTF_8)
                else contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error("Could not read the selected backup file.")
            restoreBackupJson(JSONObject(text))
            AlertDialog.Builder(this).setTitle("Backup Restored")
                .setMessage("Your saved setlists, notes, history, and settings have been restored. Return Home to refresh the displayed data.")
                .setPositiveButton("Return Home") { _, _ -> showHome() }.showWithPhoneRemote()
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle("Backup Failed")
                .setMessage(e.message ?: "The backup could not be processed.")
                .setPositiveButton("OK", null).showWithPhoneRemote()
        }
    }

    private fun buildBackupJson(): JSONObject {
        val root = JSONObject().put("format", "dph-gig-assistant-backup").put("version", 1)
        val allPrefs = JSONObject()
        backupPreferenceNames.forEach { prefName ->
            val entries = JSONObject()
            getSharedPreferences(prefName, Context.MODE_PRIVATE).all.forEach { (key, value) ->
                val entry = JSONObject()
                when (value) {
                    is String -> entry.put("type", "string").put("value", value)
                    is Boolean -> entry.put("type", "boolean").put("value", value)
                    is Int -> entry.put("type", "int").put("value", value)
                    is Long -> entry.put("type", "long").put("value", value)
                    is Float -> entry.put("type", "float").put("value", value.toDouble())
                    is Set<*> -> entry.put("type", "string_set").put("value", JSONArray(value.filterIsInstance<String>()))
                }
                if (entry.has("type")) entries.put(key, entry)
            }
            allPrefs.put(prefName, entries)
        }
        root.put("preferences", allPrefs)
        return root
    }

    private fun restoreBackupJson(root: JSONObject) {
        require(root.optString("format") == "dph-gig-assistant-backup") { "This is not a Gig Assistant backup file." }
        val preferences = root.optJSONObject("preferences") ?: error("The backup file is missing its preferences data.")
        backupPreferenceNames.forEach { prefName ->
            val entries = preferences.optJSONObject(prefName) ?: return@forEach
            val editor = getSharedPreferences(prefName, Context.MODE_PRIVATE).edit().clear()
            val keys = entries.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val entry = entries.optJSONObject(key) ?: continue
                when (entry.optString("type")) {
                    "string" -> editor.putString(key, entry.optString("value"))
                    "boolean" -> editor.putBoolean(key, entry.optBoolean("value"))
                    "int" -> editor.putInt(key, entry.optInt("value"))
                    "long" -> editor.putLong(key, entry.optLong("value"))
                    "float" -> editor.putFloat(key, entry.optDouble("value").toFloat())
                    "string_set" -> {
                        val array = entry.optJSONArray("value") ?: JSONArray()
                        val values = mutableSetOf<String>()
                        for (i in 0 until array.length()) values.add(array.optString(i))
                        editor.putStringSet(key, values)
                    }
                }
            }
            editor.apply()
        }
    }

    private fun showHome(message: String? = null) {
        remoteNavigationRoot = null
        inViewer = false
        inBrowser = false
        inSavedSetlists = false
        inRecentHistory = false
        inOnlineLyrics = false
        isCountdownScreen = false
        handler.removeCallbacks(tick)
        paused = false

        val gold = Color.rgb(255, 202, 32)
        val white = Color.rgb(242, 245, 249)
        val muted = Color.rgb(175, 184, 196)

        // Use density-aware dimensions and wrap-content text containers on the home
        // screen. Fixed pixel heights were too short on Android TV densities and
        // clipped glyphs/descenders even when the text itself was correct.
        fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(responsiveDp(36, 14), dp(16), responsiveDp(36, 14), dp(20))
            setBackgroundColor(Color.rgb(10, 14, 20))
        }
        val scroller = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setBackgroundColor(Color.rgb(10, 14, 20))
            addView(content, LinearLayout.LayoutParams(-1, -2))
        }

        val title = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(5), dp(8), dp(3))
        }
        title.addView(makeText("Gig Assistant", if (isCompactScreen) 25f else 32f, white, true).apply {
            includeFontPadding = true
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-2, -2))
        val tierBadge = TextView(this).apply {
            text = if (isProEntitled()) " PRO " else " FREE "
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(if (isProEntitled()) Color.BLACK else white)
            background = GradientDrawable().apply {
                cornerRadius = dp(7).toFloat()
                setColor(if (isProEntitled()) gold else Color.rgb(48, 58, 70))
                setStroke(dp(1), if (isProEntitled()) gold else Color.rgb(112, 126, 143))
            }
            setPadding(dp(8), dp(5), dp(8), dp(5))
            contentDescription = if (isProEntitled()) "Gig Assistant Pro tier" else "Gig Assistant Free tier"
        }
        title.addView(tierBadge, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(10) })
        content.addView(title, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(0) })

        content.addView(makeText("by DPH", 16f, gold, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            includeFontPadding = true
            letterSpacing = 0.03f
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(2) })

        content.addView(makeText("YOUR SETLIST. YOUR STAGE.", 14f, muted, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            includeFontPadding = true
            letterSpacing = 0.06f
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        content.addView(View(this).apply { setBackgroundColor(gold) },
            LinearLayout.LayoutParams(-1, dp(2)).apply { bottomMargin = dp(16) })

        fun menuButton(label: String, highlighted: Boolean = false, action: () -> Unit): Button = Button(this).apply {
            text = label
            styleButton(this)
            textSize = if (isCompactScreen) 15f else 19f
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            includeFontPadding = true
            maxLines = 2
            setPadding(responsiveDp(14, 8), dp(10), responsiveDp(14, 8), dp(10))
            if (highlighted) {
                background = buttonSurface(Color.rgb(38, 37, 26), gold)
                setTextColor(gold)
            }
            setOnClickListener { action() }
        }
        // Primary dashboard actions: keep the first screen focused on the three most common tasks.
        fun dashboardAction(label: String, subtitle: String, action: () -> Unit): LinearLayout {
            lateinit var titleView: TextView
            lateinit var subtitleView: TextView
            val normalFill = Color.rgb(20, 28, 39)
            val normalStroke = Color.rgb(62, 75, 91)
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = buttonSurface(normalFill, normalStroke)
                isFocusable = true
                isFocusableInTouchMode = !isCompactScreen
                isClickable = true
                setOnFocusChangeListener { view, hasFocus ->
                    view.background = buttonSurface(
                        if (hasFocus) gold else normalFill,
                        if (hasFocus) Color.rgb(255, 225, 105) else normalStroke)
                    titleView.setTextColor(if (hasFocus) Color.rgb(15, 19, 25) else white)
                    subtitleView.setTextColor(if (hasFocus) Color.rgb(35, 39, 44) else muted)
                    view.elevation = if (hasFocus) dp(3).toFloat() else 0f
                }
                setOnClickListener { action() }
                contentDescription = "$label. $subtitle"
            }
            titleView = makeText(label, 19f, white, true).apply {
                gravity = Gravity.CENTER
                textAlignment = View.TEXT_ALIGNMENT_CENTER
                maxLines = 2
            }
            subtitleView = makeText(subtitle, 12f, muted).apply {
                gravity = Gravity.CENTER
                textAlignment = View.TEXT_ALIGNMENT_CENTER
                maxLines = 2
            }
            tile.addView(titleView, LinearLayout.LayoutParams(-1, -2))
            tile.addView(subtitleView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
            return tile
        }
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val browse = dashboardAction("Start Performance", "Load lyric files") { pickFiles() }
        actionRow.addView(browse, LinearLayout.LayoutParams(0, responsiveDp(94, 62), 1f).apply { rightMargin = dp(8) })
        val setlistsAction = dashboardAction("Setlists", "Open saved sets") { showSavedSetlists() }
        actionRow.addView(setlistsAction, LinearLayout.LayoutParams(0, responsiveDp(94, 62), 1f).apply { leftMargin = dp(8) })
        content.addView(actionRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        val recentAction = dashboardAction("Recently Played", "Replay recent songs or sets") { showRecentHistory() }
        content.addView(recentAction, LinearLayout.LayoutParams(-1, responsiveDp(94, 62)).apply { bottomMargin = dp(16) })

        // Collapsible home-screen sections keep the TV interface compact as features grow.
        fun addHomeSection(title: String, initiallyExpanded: Boolean): LinearLayout {
            val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = if (initiallyExpanded) View.VISIBLE else View.GONE }
            val header = Button(this).apply {
                text = (if (initiallyExpanded) "▼  " else "▶  ") + title
                styleButton(this)
                textSize = 17f
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(8), dp(16), dp(8))
                background = buttonSurface(Color.rgb(22, 29, 39), Color.rgb(74, 86, 101))
                setOnClickListener {
                    val expand = panel.visibility != View.VISIBLE
                    panel.visibility = if (expand) View.VISIBLE else View.GONE
                    text = (if (expand) "▼  " else "▶  ") + title
                    if (expand) {
                        panel.post {
                            scroller.smoothScrollTo(0, (panel.top - dp(8)).coerceAtLeast(0))
                            val firstOption = (0 until panel.childCount).asSequence()
                                .map { panel.getChildAt(it) }.firstOrNull { it.isFocusable && it.isShown }
                            firstOption?.requestFocus()
                        }
                    }
                }
            }
            content.addView(header, LinearLayout.LayoutParams(-1, responsiveDp(50, 42)).apply { bottomMargin = dp(5) })
            content.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            return panel
        }
        // Saved Setlists and Recently Played are available directly from the home tiles.
        val featuresPanel = addHomeSection("Pro Features & Upgrade", false)
        val helpPanel = addHomeSection("Settings & Help", false)

        if (lastLoadedQueue.isNotEmpty()) {
            val saveSet = menuButton("Save Current Setlist") { promptSaveSetlist() }
            featuresPanel.addView(saveSet, LinearLayout.LayoutParams(-1, responsiveDp(58, 46)).apply { bottomMargin = dp(8) })
        }

        // The resume option only exists after a set has actually been loaded.
        // Do not show a dead-end button on a fresh launch or before selecting files.
        if (lastLoadedQueue.isNotEmpty()) {
            val resume = menuButton("Play last loaded set") {
                queue = lastLoadedQueue.toMutableList()
                currentSongIndex = 0
                isQueueMode = queue.size > 1
                playCurrent()
            }
            featuresPanel.addView(resume, LinearLayout.LayoutParams(-1, responsiveDp(58, 46)).apply { bottomMargin = dp(6) })

            // Keep queue status immediately below the option it describes.
            if (message != null &&
                (message.startsWith("Queue finished") || message.startsWith("Queue cancelled") ||
                 message.startsWith("Playback stopped"))) {
                featuresPanel.addView(makeText(message, 15f, gold).apply {
                    gravity = Gravity.CENTER
                    textAlignment = View.TEXT_ALIGNMENT_CENTER
                    includeFontPadding = true
                    maxLines = 2
                }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            } else {
                featuresPanel.addView(View(this), LinearLayout.LayoutParams(1, dp(4)))
            }
        }

        val pro = menuButton("Gig Assistant Pro  •  Free / Pro Features") { showProUpgrade() }
        featuresPanel.addView(pro, LinearLayout.LayoutParams(-1, responsiveDp(58, 46)).apply { bottomMargin = dp(8) })

        val about = menuButton("About DPH Gig Assistant") {
            AlertDialog.Builder(this)
                .setTitle("DPH Gig Assistant — About & Features")
                .setMessage("DPH GIG ASSISTANT\nYOUR SETLIST. YOUR STAGE.\n\nGig Assistant is a remote-friendly lyric teleprompter designed for rehearsals and live performance.\n\nLYRICS & LIBRARY\n• Load plain-text (.txt) lyric files from device storage or USB storage.\n• Connect to supported online lyric repositories and load lyrics from saved locations.\n• Build a playback queue, arrange songs, and play through your set.\n\nSETLISTS & HISTORY\n• Save, rename, edit, reorder, duplicate, and delete setlists.\n• Add setlist notes for venues, dates, and reminders, plus song notes for arrangement cues (Pro feature).\n• Recently Played lets you replay recent songs or setlists, remove individual entries, or clear history. History actions do not delete your song or setlist files.\n\nPLAYBACK & VOICE\n• Use the TV remote to pause/resume, adjust scroll speed and text size, and navigate playback.\n• Voice commands can control playback when voice recognition is available.\n• Performance Mode displays the current song, next song, and saved notes (Pro feature).\n• A phone remote can control the TV app over your local network.\n\nBACKUP & RESTORE\n• Export or import a backup of supported app data, including setlists, notes, and settings. Keep a copy of your backup somewhere safe.\n\nFREE & PRO\n• Online Lyrics and core lyric playback are available in this test build.\n• Pro features include per-song speed/font settings and Performance Mode. Pro purchasing is not enabled in this test build; the Free/Pro switch is for testing only.\n\nHELP & FEEDBACK\nFor feature requests, questions, or to report a problem, email: gigassistantdph@gmail.com")
                .setPositiveButton("OK", null)
                .setNeutralButton("Email Support") { _, _ -> openSupportEmail() }
                .showWithPhoneRemote()
        }
        helpPanel.addView(about, LinearLayout.LayoutParams(-1, responsiveDp(58, 46)).apply { bottomMargin = dp(8) })

        val contact = menuButton("Contact Support / Report a Problem") { openSupportEmail() }
        helpPanel.addView(contact, LinearLayout.LayoutParams(-1, responsiveDp(58, 46)).apply { bottomMargin = dp(8) })

        val upgradeButton = menuButton("Check for App Updates") { checkForAppUpdate() }
        updateAvailableButton = upgradeButton
        helpPanel.addView(upgradeButton, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { bottomMargin = dp(8) })

        val phoneRemote = menuButton("Phone Remote Control") { showPhoneRemote() }
        helpPanel.addView(phoneRemote, LinearLayout.LayoutParams(-1, responsiveDp(58, 46)).apply { bottomMargin = dp(8) })

        val exportBackup = menuButton("Export Backup (Setlists, Notes & Settings)") { startBackupExport() }
        helpPanel.addView(exportBackup, LinearLayout.LayoutParams(-1, responsiveDp(58, 46)).apply { bottomMargin = dp(8) })
        val importBackup = menuButton("Import Backup") { confirmBackupImport() }
        helpPanel.addView(importBackup, LinearLayout.LayoutParams(-1, responsiveDp(58, 46)).apply { bottomMargin = dp(8) })

        val settingsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = buttonSurface(Color.rgb(17, 23, 32), Color.rgb(54, 64, 78))
        }
        settingsPanel.addView(makeText("Delay Between Songs (in seconds)", 17f, muted, true).apply {
            gravity = Gravity.CENTER
            includeFontPadding = true
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(16) })
        val delayInput = EditText(this).apply {
            setText(queueDelaySeconds.toString())
            textSize = 20f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            // Use the phone remote's text-entry field instead of opening the Android TV
            // number keyboard, which can trap focus above the app and obscure navigation.
            showSoftInputOnFocus = remoteServerRunning.get().not()
            setSelectAllOnFocus(true)
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = buttonSurface(Color.rgb(38, 45, 55), gold)
            gravity = Gravity.CENTER
            isFocusable = true
            isFocusableInTouchMode = true
            includeFontPadding = true
        }
        delayInputRef = delayInput
        settingsPanel.addView(delayInput, LinearLayout.LayoutParams(responsiveDp(84, 76), responsiveDp(48, 42)))
        helpPanel.addView(settingsPanel, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        helpPanel.addView(makeText("REMOTE CONTROLS", 12f, gold, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            letterSpacing = 0.12f
            includeFontPadding = true
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(3) })
        helpPanel.addView(makeText("During playback: OK Pause / Resume  •  ◀ ▶ Speed", 13f, muted).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            includeFontPadding = true
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(2) })
        helpPanel.addView(makeText("▲ ▼ Font size  •  BACK Next Up / Menu", 13f, muted).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            includeFontPadding = true
        }, LinearLayout.LayoutParams(-1, -2))

        setContentView(scroller)
        browse.requestFocus()
        delayInput.setOnFocusChangeListener { view, hasFocus ->
            if (hasFocus) view.post { delayInput.selectAll() }
            else queueDelaySeconds = delayInput.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 30
        }
        delayInput.setOnClickListener {
            delayInput.requestFocus()
            delayInput.selectAll()
            scroller.post { scroller.smoothScrollTo(0, settingsPanel.top) }
            if (!remoteServerRunning.get()) {
                // TV-only mode: a single Select opens the native numeric keyboard.
                delayInput.showSoftInputOnFocus = true
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                imm?.showSoftInput(delayInput, InputMethodManager.SHOW_IMPLICIT)
            } else {
                // Phone mode: leave the TV keyboard closed; use Phone Text Entry.
                delayInput.showSoftInputOnFocus = false
                (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
                    ?.hideSoftInputFromWindow(delayInput.windowToken, 0)
            }
        }
        delayInput.setOnLongClickListener {
            // Keep long-press harmless; single-click is the normal TV keyboard action.
            delayInput.performClick()
            true
        }
        fun commitDelayAndCloseKeyboard() {
            queueDelaySeconds = delayInput.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 30
            (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
                ?.hideSoftInputFromWindow(delayInput.windowToken, 0)
            delayInput.clearFocus()
            delayInput.showSoftInputOnFocus = remoteServerRunning.get().not()
            scroller.post { scroller.smoothScrollTo(0, 0) }
            Toast.makeText(this, "Delay set to ${queueDelaySeconds}s", Toast.LENGTH_SHORT).show()
        }
        delayInput.setOnEditorActionListener { _, _, _ ->
            commitDelayAndCloseKeyboard()
            true
        }
        delayInput.setOnKeyListener { _, keyCode, event ->
            if ((keyCode == android.view.KeyEvent.KEYCODE_ENTER || keyCode == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER) &&
                event.action == android.view.KeyEvent.ACTION_UP) {
                commitDelayAndCloseKeyboard()
                true
            } else false
        }
    }

    private var delayInputRef: EditText? = null

    private fun openSupportEmail() {
        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:gigassistantdph@gmail.com")
            putExtra(Intent.EXTRA_SUBJECT, "Gig Assistant Support Request")
            putExtra(Intent.EXTRA_TEXT, "\n\nApp version: 1.13.21\nDevice / Android TV model: ")
        }
        try {
            startActivity(Intent.createChooser(emailIntent, "Email Gig Assistant Support"))
        } catch (_: Exception) {
            // Android TV devices often have no email client installed. Keep support usable
            // by showing a selectable address and a one-click copy action instead.
            val address = TextView(this).apply {
                text = "gigassistantdph@gmail.com"
                textSize = 19f
                setTextColor(Color.rgb(255, 202, 32))
                setTextIsSelectable(true)
                setPadding(dp(20), dp(12), dp(20), dp(12))
                gravity = Gravity.CENTER
            }
            AlertDialog.Builder(this)
                .setTitle("Contact Gig Assistant Support")
                .setMessage("This TV does not have an email app installed. Use a phone or computer to send your request, or copy the address below.")
                .setView(address)
                .setPositiveButton("Copy Email Address") { _, _ ->
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Gig Assistant Support", "gigassistantdph@gmail.com"))
                    Toast.makeText(this, "Support email copied", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Close", null)
                .showWithPhoneRemote()
        }
    }

    private fun pickFiles() {
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_STORAGE_PERMISSION)
            return
        }
        selectedFilePaths.clear()
        browserMessage = null
        browserDirectory = null
        showFileBrowser()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_STORAGE_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                selectedFilePaths.clear()
                browserMessage = null
                browserDirectory = null
                showFileBrowser()
            } else {
                showHome("Storage permission is needed to browse song files. Please allow it in App settings.")
            }
        }
        if (requestCode == REQUEST_MIC_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                voiceStatusMessage = "Microphone permission granted. Starting voice recognition…"
                updateStatus()
                launchSpeechRecognition()
            } else {
                voiceStatusMessage = "Microphone permission denied. Enable Microphone in Android App settings."
                updateStatus()
                Toast.makeText(this, "Microphone permission is required for voice commands", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun storageRoots(): List<java.io.File> {
        val roots = linkedMapOf<String, java.io.File>()
        val internal = Environment.getExternalStorageDirectory()
        if (internal.isDirectory && internal.canRead()) roots[internal.absolutePath] = internal
        val storage = java.io.File("/storage")
        storage.listFiles()?.filter { it.isDirectory && it.name !in setOf("emulated", "self") }?.forEach { volume ->
            if (volume.canRead()) roots[volume.absolutePath] = volume
        }
        return roots.values.toList()
    }

    private fun showFileBrowser() {
        inBrowser = true
        inViewer = false
        inSavedSetlists = false
        val current = browserDirectory
        val root = verticalLayout().apply { setPadding(42, 24, 42, 26) }
        val browserTitle = makeText("‹   Browse Files", 30f, Color.rgb(255, 205, 35), true).apply {
            gravity = Gravity.CENTER
            setPadding(12, 12, 12, 16)
            includeFontPadding = true
            setLineSpacing(4f, 1.0f)
            minHeight = 86
            maxLines = 1
        }
        root.addView(browserTitle, LinearLayout.LayoutParams(-1, 108).apply { bottomMargin = 8 })
        val pathLabel = makeText(current?.absolutePath ?: "Choose Internal Storage, a USB drive, or Browse Online Lyrics (github)", 16f, Color.LTGRAY).apply {
            gravity = if (current == null) Gravity.CENTER else Gravity.START or Gravity.CENTER_VERTICAL
            maxLines = 3
            setPadding(4, 4, 4, 4)
        }
        root.addView(pathLabel, LinearLayout.LayoutParams(-1, 52).apply { bottomMargin = 6 })
        if (browserMessage != null) {
            val messageLabel = makeText(browserMessage!!, 17f, Color.YELLOW).apply { setPadding(4, 4, 4, 4) }
            root.addView(messageLabel, LinearLayout.LayoutParams(-1, 46).apply { bottomMargin = 4 })
        }

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { isFillViewport = false; addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun addFolder(file: java.io.File, label: String = file.name) {
            val b = Button(this).apply {
                text = "📁  $label"
                styleButton(this)
                gravity = if (current == null) Gravity.CENTER else Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener { browserDirectory = file; browserMessage = null; browserFocusedPath = null; browserScrollY = 0; showFileBrowser() }
            }
            b.textSize = 18f
            b.maxLines = 2
            b.includeFontPadding = true
            list.addView(b, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { setMargins(0, dp(4), 0, dp(4)) })
        }
        fun addTextFile(file: java.io.File) {
            val chosen = selectedFilePaths.contains(file.absolutePath)
            val b = Button(this).apply {
                tag = file.absolutePath
                text = (if (chosen) "☑  " else "☐  ") + displaySongName(file.name)
                styleButton(this)
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                background = buttonSurface(if (chosen) Color.rgb(56, 62, 43) else Color.rgb(24, 31, 41), if (chosen) Color.rgb(170, 145, 45) else Color.rgb(65, 75, 88))
                textSize = 18f
                maxLines = 2
                includeFontPadding = true
                setPadding(22, 12, 22, 12)
                setOnFocusChangeListener { view, hasFocus ->
                    val focusedButton = view as Button
                    if (hasFocus) {
                        focusedButton.background = buttonSurface(Color.rgb(255, 202, 32), Color.rgb(255, 225, 105))
                        focusedButton.setTextColor(Color.BLACK)
                    } else {
                        val selected = selectedFilePaths.contains(file.absolutePath)
                        focusedButton.background = buttonSurface(if (selected) Color.rgb(56, 62, 43) else Color.rgb(24, 31, 41), if (selected) Color.rgb(170, 145, 45) else Color.rgb(65, 75, 88))
                        focusedButton.setTextColor(Color.WHITE)
                    }
                }
                setOnClickListener {
                    // Save the current location before rebuilding the buttons, then return focus
                    // to this same file instead of jumping back to the top of the directory.
                    browserFocusedPath = file.absolutePath
                    browserScrollY = scroll.scrollY
                    if (selectedFilePaths.contains(file.absolutePath)) selectedFilePaths.remove(file.absolutePath)
                    else selectedFilePaths.add(file.absolutePath)
                    browserMessage = "${selectedFilePaths.size} file(s) selected"
                    showFileBrowser()
                }
            }
            list.addView(b, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { setMargins(0, dp(4), 0, dp(4)) })
        }

        if (current == null) {
            val roots = storageRoots()
            if (roots.isEmpty()) {
                list.addView(makeText("No readable storage was found. Connect a USB drive or check Android storage permissions.", 19f, Color.YELLOW),
                    LinearLayout.LayoutParams(-1, 80))
            } else {
                roots.forEach { f -> addFolder(f, if (f.absolutePath == Environment.getExternalStorageDirectory().absolutePath) "Internal Storage" else "USB / external: ${f.name}") }
            }
        } else {
            val up = current.parentFile
            val drives = Button(this).apply {
                text = "⬆  ${if (up == null) "Storage locations" else "Parent folder"}"
                styleButton(this)
                setOnClickListener { browserDirectory = up; browserMessage = null; browserFocusedPath = null; browserScrollY = 0; showFileBrowser() }
            }
            drives.textSize = 18f
            drives.includeFontPadding = true
            drives.minHeight = responsiveDp(68, 48)
            drives.setPadding(dp(18), dp(8), dp(18), dp(8))
            list.addView(drives, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { setMargins(0, dp(4), 0, dp(4)) })
            val children = current.listFiles()?.filter { it.isDirectory || (it.isFile && it.extension.equals("txt", true)) }
                ?.sortedWith(compareBy<java.io.File>({ !it.isDirectory }, { it.name.lowercase(Locale.ROOT) }))
            if (children.isNullOrEmpty()) {
                list.addView(makeText("No folders or .txt files in this location.", 19f, Color.LTGRAY), LinearLayout.LayoutParams(-1, 60))
            } else {
                children.forEach { f -> if (f.isDirectory) addFolder(f) else addTextFile(f) }
            }
        }

        val onlineButton = Button(this).apply {
            text = "🌐  Browse Online Lyrics"
            styleButton(this)
            gravity = Gravity.CENTER
            textSize = 17f
            maxLines = 2
            includeFontPadding = true
            setPadding(18, 12, 18, 12)
            setOnClickListener { showOnlineLocations() }
        }
        list.addView(onlineButton, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { setMargins(0, dp(4), 0, dp(4)) })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val upButton = Button(this).apply {
            text = "Storage / Up"; styleButton(this)
            setOnClickListener { browserDirectory = browserDirectory?.parentFile; browserFocusedPath = null; browserScrollY = 0; showFileBrowser() }
        }
        val loadButton = Button(this).apply {
            text = "PLAY SELECTED (${selectedFilePaths.size})"; styleButton(this)
            setOnClickListener { loadSelectedFiles() }
        }
        val cancelButton = Button(this).apply { text = "Cancel"; styleButton(this); setOnClickListener { showHome() } }
        listOf(upButton, loadButton, cancelButton).forEach { b ->
            b.textSize = 16f
            b.minHeight = responsiveDp(68, 48)
            b.maxLines = 2
            b.includeFontPadding = true
            b.setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        loadButton.background = buttonSurface(Color.rgb(255, 202, 32), Color.rgb(255, 225, 105))
        loadButton.setTextColor(Color.BLACK)
        actions.addView(upButton, LinearLayout.LayoutParams(0, responsiveDp(68, 48), 1f).apply { setMargins(5, 5, 5, 5) })
        actions.addView(loadButton, LinearLayout.LayoutParams(0, responsiveDp(68, 48), 1.35f).apply { setMargins(5, 5, 5, 5) })
        actions.addView(cancelButton, LinearLayout.LayoutParams(0, responsiveDp(68, 48), 0.8f).apply { setMargins(5, 5, 5, 5) })
        root.addView(actions, LinearLayout.LayoutParams(-1, responsiveDp(76, 58)).apply { topMargin = dp(6) })
        setContentView(root)
        root.post {
            scroll.scrollTo(0, browserScrollY.coerceAtLeast(0))
            val restore = browserFocusedPath?.let { list.findViewWithTag<View>(it) }
            if (restore != null) {
                restore.requestFocus()
            } else {
                (list.getChildAt(0) as? View)?.requestFocus() ?: loadButton.requestFocus()
            }
        }
    }

    private fun loadSelectedFiles() {
        if (selectedFilePaths.isEmpty()) {
            browserMessage = "Select one or more .txt files first."
            showFileBrowser()
            return
        }
        val loaded = mutableListOf<Song>()
        selectedFilePaths.forEach { path ->
            try {
                val file = java.io.File(path)
                if (file.isFile && file.extension.equals("txt", true) && file.canRead()) {
                    val text = file.readText(Charsets.UTF_8)
                    if (text.isNotBlank()) loaded.add(Song(Uri.fromFile(file), displaySongName(file.name), text))
                }
            } catch (_: Exception) { }
        }
        if (loaded.isEmpty()) {
            browserMessage = "No selected files could be read. Try internal storage or another USB location."
            showFileBrowser()
            return
        }
        // Show the same review dialog used by online selection before playback starts.
        // Cancel returns to the current local/USB folder with its selections intact.
        queue = loaded.toMutableList()
        lastLoadedQueue = loaded.toMutableList()
        currentSongIndex = 0
        isQueueMode = queue.size > 1
        confirmQueue { showFileBrowser() }
    }

    private fun startLoadedQueue(loaded: MutableList<Song>, setlistName: String? = null) {
        currentSetlistName = setlistName
        queue = loaded
        lastLoadedQueue = loaded.toMutableList()
        currentSongIndex = 0
        isQueueMode = queue.size > 1
        if (queue.size == 1) {
            AlertDialog.Builder(this)
                .setTitle("One song selected")
                .setMessage("Would you like the lyrics to repeat continuously until you press BACK?\n\nGreat for learning a new song.")
                .setPositiveButton("Repeat until BACK") { _, _ ->
                    repeatSingleSongUntilBack = true
                    playCurrent()
                }
                .setNegativeButton("Play once") { _, _ ->
                    repeatSingleSongUntilBack = false
                    playCurrent()
                }
                .setNeutralButton("Cancel", null)
                .setCancelable(true)
                .showWithPhoneRemote()
        } else {
            repeatSingleSongUntilBack = false
            playCurrent()
        }
    }

    private fun promptSaveSetlist() {
        if (lastLoadedQueue.isEmpty()) {
            Toast.makeText(this, "Load one or more songs first.", Toast.LENGTH_SHORT).show()
            return
        }
        val input = EditText(this).apply {
            hint = "Setlist name"
            setSingleLine(true)
            textSize = 20f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(24, 18, 24, 18)
        }
        AlertDialog.Builder(this)
            .setTitle("Save Current Setlist")
            .setMessage("Save the current song selection so you can load it again later.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isBlank()) {
                    Toast.makeText(this, "Enter a name for the setlist.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val paths = lastLoadedQueue.map { it.uri.toString() }
                setlistPrefs.edit().putString("setlist:$name", paths.joinToString("\n")).apply()
                Toast.makeText(this, "Saved setlist: $name", Toast.LENGTH_SHORT).show()
                showHome()
            }
            .setNegativeButton("Cancel", null)
            .showWithPhoneRemote()
    }

    private fun showSavedSetlists() {
        inViewer = false
        inBrowser = false
        inSavedSetlists = true
        inRecentHistory = false
        isCountdownScreen = false
        handler.removeCallbacks(tick)
        val root = verticalLayout()
        root.addView(makeText("Saved Setlists", 28f, Color.rgb(255, 205, 35), true).apply {
            gravity = Gravity.CENTER
            setPadding(8, 4, 8, 4)
            includeFontPadding = true
            maxLines = 1
        }, LinearLayout.LayoutParams(-1, 96))
        root.addView(makeText("Choose a setlist to load, or delete one you no longer need.", 17f, Color.LTGRAY),
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val entries = setlistPrefs.all.keys.filter { it.startsWith("setlist:") }
            .map { it.removePrefix("setlist:") }.sortedBy { it.lowercase(Locale.ROOT) }
        if (entries.isEmpty()) {
            list.addView(makeText("No saved setlists yet. Load songs, then choose Save Current Setlist.", 19f, Color.LTGRAY),
                LinearLayout.LayoutParams(-1, 100))
        } else {
            entries.forEach { name ->
                // Keep the setlist name and its actions together on one horizontal row.
                // Give the name a limited share of the width so action buttons remain visible
                // on TV screens and within overscan-safe margins.
                val item = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(8, 5, 8, 7)
                    gravity = Gravity.CENTER_VERTICAL
                }
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val load = Button(this).apply {
                    text = name
                    styleButton(this)
                    gravity = Gravity.START or Gravity.CENTER_VERTICAL
                    textSize = 17f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    includeFontPadding = true
                    setPadding(10, 6, 8, 6)
                    setOnClickListener { loadSavedSetlist(name) }
                }
                row.addView(load, LinearLayout.LayoutParams(0, 68, 1.7f).apply {
                    setMargins(0, 3, 5, 3)
                })

                fun actionButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
                    text = label
                    styleButton(this)
                    textSize = 14f
                    maxLines = 1
                    includeFontPadding = true
                    setPadding(2, 5, 2, 5)
                    minWidth = 0
                    minimumWidth = 0
                    setOnClickListener { onClick() }
                }
                fun addAction(label: String, onClick: () -> Unit) {
                    row.addView(actionButton(label, onClick), LinearLayout.LayoutParams(0, responsiveDp(62, 48), 0.75f).apply {
                        setMargins(3, 3, 3, 3)
                    })
                }
                addAction("Edit") { editSavedSetlist(name) }
                addAction("Duplicate") { promptDuplicateSetlist(name) }
                addAction("Notes") { editSetlistNotes(name) }
                addAction("Delete") {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Delete '$name'?")
                        .setMessage("This removes the saved setlist, not the lyric files.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete") { _, _ ->
                            setlistPrefs.edit().remove("setlist:$name").apply()
                            notesPrefs.edit().remove("setlist_note:$name").apply()
                            showSavedSetlists()
                        }.showWithPhoneRemote()
                }
                item.addView(row, LinearLayout.LayoutParams(-1, 74))
                item.addView(View(this).apply {
                    setBackgroundColor(Color.argb(70, 255, 255, 255))
                }, LinearLayout.LayoutParams(-1, 1).apply {
                    setMargins(0, 4, 0, 4)
                })
                list.addView(item, LinearLayout.LayoutParams(-1, -2))
            }
        }
        setContentView(root)
        if (entries.isNotEmpty()) {
            (list.getChildAt(0) as? View)?.requestFocus()
        } else {
            list.requestFocus()
        }
    }

    private fun editSetlistNotes(setlistName: String) {
        if (!hasProFeatureAccess(ProFeature.SETLIST_NOTES)) {
            showProFeatureRequired("Setlist notes")
            return
        }
        val previousRemoteDialog = remoteNavigationDialog
        val previousRemoteRoot = remoteNavigationRoot
        val key = "setlist_note:$setlistName"
        val input = EditText(this).apply {
            setText(notesPrefs.getString(key, "") ?: "")
            hint = "Venue, date, reminders, set instructions…"
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            textSize = 18f; gravity = Gravity.TOP or Gravity.START
            minLines = 5; maxLines = 10
            setPadding(18, 14, 18, 14)
            background = buttonSurface(Color.rgb(17, 23, 32), Color.rgb(65, 75, 88))
            // Only suppress the Android TV keyboard while the phone remote is active.
            if (remoteServerRunning.get()) showSoftInputOnFocus = false
        }
        val dialog = AlertDialog.Builder(this).setTitle("Setlist Notes: $setlistName")
            .setView(input).setPositiveButton("Save", null).setNegativeButton("Cancel", null).create()
        dialog.setOnShowListener {
            // Route phone remote navigation into the active notes dialog instead of the screen behind it.
            remoteNavigationDialog = dialog
            remoteNavigationRoot = dialog.window?.decorView
            dialog.window?.decorView?.let { applyRemoteKeyboardPolicy(it) }
            input.requestFocus()
            if (remoteServerRunning.get()) {
                input.showSoftInputOnFocus = false
                (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
                    ?.hideSoftInputFromWindow(input.windowToken, 0)
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                notesPrefs.edit().putString(key, input.text.toString().trim()).apply()
                dialog.dismiss()
                Toast.makeText(this, "Setlist notes saved.", Toast.LENGTH_SHORT).show()
            }
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.82).toInt(), (resources.displayMetrics.heightPixels * 0.72).toInt())
        }
        dialog.setOnDismissListener {
            if (remoteNavigationDialog === dialog) {
                if (previousRemoteDialog != null && previousRemoteDialog.isShowing) {
                    remoteNavigationDialog = previousRemoteDialog
                    remoteNavigationRoot = previousRemoteRoot?.takeIf { it.isShown }
                        ?: previousRemoteDialog.window?.decorView
                    remoteNavigationRoot?.post { findFirstFocusable(remoteNavigationRoot!!)?.requestFocus() }
                } else {
                    remoteNavigationDialog = null
                    remoteNavigationRoot = null
                }
            }
        }
        dialog.show()
    }

    private fun editSongNotes(uriString: String, songName: String) {
        if (!hasProFeatureAccess(ProFeature.SONG_NOTES)) {
            showProFeatureRequired("Song notes")
            return
        }
        val previousRemoteDialog = remoteNavigationDialog
        val previousRemoteRoot = remoteNavigationRoot
        val key = "song_note:$uriString"
        val input = EditText(this).apply {
            setText(notesPrefs.getString(key, "") ?: "")
            hint = "Intro: 4 bars; skip second chorus; end on final chord…"
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            textSize = 18f; gravity = Gravity.TOP or Gravity.START
            minLines = 4; maxLines = 8
            setPadding(18, 14, 18, 14)
            background = buttonSurface(Color.rgb(17, 23, 32), Color.rgb(65, 75, 88))
            // Only suppress the Android TV keyboard while the phone remote is active.
            if (remoteServerRunning.get()) showSoftInputOnFocus = false
        }
        val dialog = AlertDialog.Builder(this).setTitle("Song Notes: $songName")
            .setView(input).setPositiveButton("Save", null).setNegativeButton("Cancel", null).create()
        dialog.setOnShowListener {
            remoteNavigationDialog = dialog
            remoteNavigationRoot = dialog.window?.decorView
            dialog.window?.decorView?.let { applyRemoteKeyboardPolicy(it) }
            input.requestFocus()
            if (remoteServerRunning.get()) {
                input.showSoftInputOnFocus = false
                (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
                    ?.hideSoftInputFromWindow(input.windowToken, 0)
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                notesPrefs.edit().putString(key, input.text.toString().trim()).apply()
                dialog.dismiss()
                Toast.makeText(this, "Song notes saved.", Toast.LENGTH_SHORT).show()
            }
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.82).toInt(), (resources.displayMetrics.heightPixels * 0.72).toInt())
        }
        dialog.setOnDismissListener {
            if (remoteNavigationDialog === dialog) {
                if (previousRemoteDialog != null && previousRemoteDialog.isShowing) {
                    remoteNavigationDialog = previousRemoteDialog
                    remoteNavigationRoot = previousRemoteRoot?.takeIf { it.isShown }
                        ?: previousRemoteDialog.window?.decorView
                    remoteNavigationRoot?.post { findFirstFocusable(remoteNavigationRoot!!)?.requestFocus() }
                } else {
                    remoteNavigationDialog = null
                    remoteNavigationRoot = null
                }
            }
        }
        dialog.show()
    }

    private fun promptDuplicateSetlist(sourceName: String) {
        val stored = setlistPrefs.getString("setlist:$sourceName", null)
        if (stored == null) {
            Toast.makeText(this, "That setlist no longer exists.", Toast.LENGTH_SHORT).show()
            showSavedSetlists()
            return
        }
        val input = EditText(this).apply {
            setText("$sourceName Copy")
            hint = "New setlist name"
            setSingleLine(true)
            textSize = 20f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(24, 18, 24, 18)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Duplicate Setlist")
            .setMessage("Create an independent copy of '$sourceName'. The original will not be changed.")
            .setView(input)
            .setPositiveButton("Duplicate", null)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.setOnShowListener {
            remoteNavigationDialog = dialog
            remoteNavigationRoot = dialog.window?.decorView
            input.requestFocus()
            if (remoteServerRunning.get()) {
                input.showSoftInputOnFocus = false
                (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
                    ?.hideSoftInputFromWindow(input.windowToken, 0)
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val newName = input.text.toString().trim()
                if (newName.isBlank()) {
                    input.error = "Enter a name"
                    return@setOnClickListener
                }
                if (setlistPrefs.contains("setlist:$newName")) {
                    input.error = "A setlist with that name already exists"
                    return@setOnClickListener
                }
                setlistPrefs.edit().putString("setlist:$newName", stored).apply()
                val sourceNotes = notesPrefs.getString("setlist_note:$sourceName", null)
                if (sourceNotes != null) notesPrefs.edit().putString("setlist_note:$newName", sourceNotes).apply()
                dialog.dismiss()
                Toast.makeText(this, "Duplicated as '$newName'.", Toast.LENGTH_SHORT).show()
                showSavedSetlists()
            }
        }
        dialog.setOnDismissListener {
            if (remoteNavigationDialog === dialog) { remoteNavigationDialog = null; remoteNavigationRoot = null }
        }
        dialog.show()
    }

    private fun addHistoryEntry(kind: String, name: String, value: String) {
        try {
            val old = JSONArray(historyPrefs.getString("entries", "[]") ?: "[]")
            val updated = JSONArray()
            // Keep the newest matching entry at the top rather than accumulating repeats.
            for (i in 0 until old.length()) {
                val item = old.optJSONObject(i) ?: continue
                if (item.optString("kind") == kind && item.optString("value") == value) continue
                updated.put(item)
            }
            val entry = JSONObject().apply {
                put("kind", kind)
                put("name", name)
                put("value", value)
                put("playedAt", System.currentTimeMillis())
            }
            val final = JSONArray().put(entry)
            for (i in 0 until minOf(updated.length(), 49)) final.put(updated.getJSONObject(i))
            historyPrefs.edit().putString("entries", final.toString()).apply()
        } catch (_: Exception) { }
    }

    private fun showRecentHistory() {
        inViewer = false
        inBrowser = false
        inSavedSetlists = false
        inRecentHistory = true
        inOnlineLyrics = false
        isCountdownScreen = false
        handler.removeCallbacks(tick)
        val root = verticalLayout()
        root.addView(makeText("Recently Played", 28f, Color.rgb(255, 205, 35), true).apply {
            gravity = Gravity.CENTER
            setPadding(8, 4, 8, 4)
            maxLines = 1
        }, LinearLayout.LayoutParams(-1, 88))
        val pro = isProEntitled()
        val maxEntries = if (pro) 50 else 5
        root.addView(makeText(if (pro) "Showing up to 50 recent songs and setlists." else "Free keeps your 5 most recent items. Pro extends history to 50 items.", 16f, Color.LTGRAY),
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val all = try { JSONArray(historyPrefs.getString("entries", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val entries = (0 until all.length()).mapNotNull { all.optJSONObject(it) }.take(maxEntries)
        if (entries.isEmpty()) {
            list.addView(makeText("Nothing played yet. Songs and saved setlists will appear here automatically.", 19f, Color.LTGRAY),
                LinearLayout.LayoutParams(-1, 100))
        } else {
            entries.forEach { item ->
                val kind = item.optString("kind", "song")
                val name = item.optString("name", "Unknown")
                val value = item.optString("value", "")
                val time = item.optLong("playedAt", 0L)
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val label = Button(this).apply {
                    text = (if (kind == "setlist") "SETLIST · " else "SONG · ") + name
                    styleButton(this)
                    gravity = Gravity.START or Gravity.CENTER_VERTICAL
                    textSize = 17f
                    maxLines = 2
                    setPadding(14, 8, 14, 8)
                    contentDescription = "Play $name"
                    setOnClickListener {
                        if (kind == "setlist") {
                            if (setlistPrefs.contains("setlist:$value")) loadSavedSetlist(value)
                            else Toast.makeText(this@MainActivity, "That saved setlist has been deleted.", Toast.LENGTH_SHORT).show()
                        } else loadRecentSong(name, value)
                    }
                }
                val remove = Button(this).apply {
                    text = "Remove"
                    styleButton(this)
                    textSize = 15f
                    setOnClickListener {
                        removeHistoryEntry(kind, value)
                        showRecentHistory()
                    }
                }
                row.addView(label, LinearLayout.LayoutParams(0, responsiveDp(72, 54), 1f).apply { setMargins(0, dp(5), dp(8), dp(5)) })
                row.addView(remove, LinearLayout.LayoutParams(responsiveDp(112, 88), responsiveDp(72, 54)).apply { setMargins(0, dp(5), 0, dp(5)) })
                list.addView(row)
            }
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val clear = Button(this).apply {
            text = "Clear History"; styleButton(this); textSize = 16f
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setTitle("Clear recent history?")
                    .setMessage("This clears the recent list only. It does not delete songs or setlists.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Clear") { _, _ -> historyPrefs.edit().remove("entries").apply(); showRecentHistory() }.showWithPhoneRemote()
            }
        }
        val back = Button(this).apply { text = "Home"; styleButton(this); textSize = 16f; setOnClickListener { showHome() } }
        buttons.addView(clear, LinearLayout.LayoutParams(0, responsiveDp(56, 46), 1f).apply { setMargins(0, dp(8), dp(8), 0) })
        buttons.addView(back, LinearLayout.LayoutParams(0, responsiveDp(56, 46), 1f).apply { setMargins(dp(8), dp(8), 0, 0) })
        root.addView(buttons, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)))
        setContentView(root)
        (list.getChildAt(0) as? View)?.requestFocus() ?: clear.requestFocus()
    }

    private fun removeHistoryEntry(kind: String, value: String) {
        val old = try { JSONArray(historyPrefs.getString("entries", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val updated = JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optString("kind") == kind && item.optString("value") == value) continue
            updated.put(item)
        }
        historyPrefs.edit().putString("entries", updated.toString()).apply()
    }

    private fun loadRecentSong(name: String, storedUri: String) {
        Toast.makeText(this, "Loading $name…", Toast.LENGTH_SHORT).show()
        Thread {
            var song: Song? = null
            try {
                if (storedUri.startsWith("https://", true)) {
                    val text = fetchText(storedUri)
                    if (text.isNotBlank()) song = Song(Uri.parse(storedUri), name, text)
                } else {
                    val uri = Uri.parse(storedUri)
                    val file = if (uri.scheme == "file") java.io.File(uri.path ?: "") else java.io.File(uri.path ?: storedUri)
                    if (file.isFile && file.canRead()) {
                        val text = file.readText(Charsets.UTF_8)
                        if (text.isNotBlank()) song = Song(Uri.fromFile(file), displaySongName(file.name), text)
                    }
                }
            } catch (_: Exception) { }
            runOnUiThread {
                if (song != null) startLoadedQueue(mutableListOf(song!!))
                else Toast.makeText(this, "Could not read that song. The file may have moved or the online source may be unavailable.", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun editSavedSetlist(name: String) {
        val stored = setlistPrefs.getString("setlist:$name", null)
        if (stored.isNullOrBlank()) {
            Toast.makeText(this, "That saved setlist is empty.", Toast.LENGTH_SHORT).show()
            showSavedSetlists()
            return
        }
        val items = stored.split("\n").filter { it.isNotBlank() }.toMutableList()
        val nameInput = EditText(this).apply {
            setText(name); hint = "Setlist name"; setSingleLine(true); textSize = 18f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setPadding(12, 10, 12, 10)
        }
        val dialogLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Use more of the TV's width and keep action buttons away from the right edge.
            setPadding(10, 8, 10, 8)
            setBackgroundColor(Color.rgb(10, 14, 20))
        }
        dialogLayout.addView(makeText("Edit the name, reorder songs, or remove songs.", 16f, Color.LTGRAY),
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6 })
        dialogLayout.addView(nameInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        val setlistNotesInput = EditText(this).apply {
            setText(notesPrefs.getString("setlist_note:$name", "") ?: "")
            hint = if (isProEntitled()) "Setlist notes (venue, date, reminders)" else "Setlist notes are a Pro feature"
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); textSize = 16f
            minLines = 2; maxLines = 3; gravity = Gravity.TOP or Gravity.START
            setPadding(12, 8, 12, 8)
            isEnabled = hasProFeatureAccess(ProFeature.SETLIST_NOTES)
            setOnFocusChangeListener { _, hasFocus -> if (hasFocus && !hasProFeatureAccess(ProFeature.SETLIST_NOTES)) showProFeatureRequired("Setlist notes") }
        }
        dialogLayout.addView(setlistNotesInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        val scroll = ScrollView(this)
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(rows)
        dialogLayout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        lateinit var dialog: AlertDialog
        var focusIndexAfterMove = -1
        var focusDirectionAfterMove = ""
        var focusTargetAfterRender: View? = null
        fun renderRows() {
            rows.removeAllViews()
            focusTargetAfterRender = null
            items.forEachIndexed { index, uriString ->
                val uri = Uri.parse(uriString)
                val rawName = uriString.substringBefore('?').substringAfterLast('/').ifBlank { "Song ${index + 1}" }
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                row.addView(makeText("${index + 1}. ${displaySongName(rawName)}", 16f, Color.WHITE).apply {
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    minWidth = 0
                }, LinearLayout.LayoutParams(0, responsiveDp(64, 50), 1f).apply { rightMargin = dp(4) })
                fun smallButton(label: String, enabled: Boolean, direction: String, action: () -> Unit): Button = Button(this).apply {
                    text = label; styleButton(this); textSize = 14f; isEnabled = enabled
                    alpha = if (enabled) 1f else 0.35f
                    setPadding(responsiveDp(5, 2), responsiveDp(8, 4), responsiveDp(5, 2), responsiveDp(8, 4)); minHeight = responsiveDp(68, 48); minimumHeight = responsiveDp(68, 48); minWidth = 0; minimumWidth = 0
                    if (index == focusIndexAfterMove && direction == focusDirectionAfterMove) focusTargetAfterRender = this
                    setOnClickListener {
                        if (direction == "up" || direction == "down") {
                            if (!enabled) return@setOnClickListener
                            val targetIndex = if (direction == "up") index - 1 else index + 1
                            items.add(targetIndex, items.removeAt(index))
                            focusIndexAfterMove = targetIndex
                            focusDirectionAfterMove = direction
                        } else {
                            action()
                        }
                        renderRows()
                        // The old button was removed with the previous row tree. Wait until
                        // Android lays out the replacement rows, then focus the matching arrow.
                        rows.post {
                            focusTargetAfterRender?.let { target ->
                                target.requestFocus()
                                target.requestFocusFromTouch()
                            }
                        }
                    }
                }
                // Give the action controls a predictable TV-friendly width. Using dp here
                // (rather than raw pixels) makes the action group wider and starts it farther
                // left, while the song title truncates instead of pushing controls off-screen.
                val actionHeight = responsiveDp(68, 48)
                row.addView(smallButton("▲", index > 0, "up") {},
                    LinearLayout.LayoutParams(responsiveDp(54, 34), actionHeight).apply { rightMargin = dp(2) })
                row.addView(smallButton("▼", index < items.lastIndex, "down") {},
                    LinearLayout.LayoutParams(responsiveDp(54, 34), actionHeight).apply { rightMargin = dp(2) })
                row.addView(smallButton("Note", true, "note") { editSongNotes(uriString, displaySongName(rawName)) },
                    LinearLayout.LayoutParams(responsiveDp(76, 48), actionHeight).apply { rightMargin = dp(2) })
                row.addView(smallButton("Remove", true, "remove") { items.removeAt(index); focusIndexAfterMove = -1; focusDirectionAfterMove = "" },
                    LinearLayout.LayoutParams(responsiveDp(88, 58), actionHeight))
                rows.addView(row, LinearLayout.LayoutParams(-1, responsiveDp(72, 56)).apply { bottomMargin = dp(4) })
            }
            if (items.isEmpty()) rows.addView(makeText("No songs in this setlist.", 18f, Color.LTGRAY), LinearLayout.LayoutParams(-1, 70))
        }
        renderRows()
        dialog = AlertDialog.Builder(this)
            .setTitle("Edit Setlist: $name")
            .setView(dialogLayout)
            .setPositiveButton("Save Changes", null)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.setOnShowListener {
            // Phone navigation must target this editor dialog, not the Saved Setlists page behind it.
            remoteNavigationDialog = dialog
            remoteNavigationRoot = dialog.window?.decorView
            dialog.window?.decorView?.let { applyRemoteKeyboardPolicy(it) }
            nameInput.requestFocus()
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val newName = nameInput.text.toString().trim()
                if (newName.isBlank()) {
                    Toast.makeText(this, "Enter a name for the setlist.", Toast.LENGTH_LONG).show()
                    nameInput.requestFocus()
                    return@setOnClickListener
                }
                if (newName != name && setlistPrefs.contains("setlist:$newName")) {
                    Toast.makeText(this, "A setlist with that name already exists.", Toast.LENGTH_LONG).show()
                    nameInput.requestFocus()
                    return@setOnClickListener
                }
                if (items.isEmpty()) {
                    AlertDialog.Builder(this).setTitle("Save an empty setlist?")
                        .setMessage("This setlist has no songs. Save it empty, or cancel and keep editing?")
                        .setNegativeButton("Keep Editing", null)
                        .setPositiveButton("Save Empty") { _, _ ->
                            val editor = setlistPrefs.edit()
                            if (newName != name) editor.remove("setlist:$name")
                            editor.putString("setlist:$newName", "").apply()
                            if (hasProFeatureAccess(ProFeature.SETLIST_NOTES)) {
                                val note = setlistNotesInput.text.toString().trim()
                                val notesEditor = notesPrefs.edit()
                                if (newName != name) notesEditor.remove("setlist_note:$name")
                                notesEditor.putString("setlist_note:$newName", note).apply()
                            }
                            dialog.dismiss(); showSavedSetlists()
                        }.showWithPhoneRemote()
                } else {
                    val editor = setlistPrefs.edit()
                    if (newName != name) editor.remove("setlist:$name")
                    editor.putString("setlist:$newName", items.joinToString("\n")).apply()
                    if (hasProFeatureAccess(ProFeature.SETLIST_NOTES)) {
                        val note = setlistNotesInput.text.toString().trim()
                        val notesEditor = notesPrefs.edit()
                        if (newName != name) notesEditor.remove("setlist_note:$name")
                        notesEditor.putString("setlist_note:$newName", note).apply()
                    }
                    Toast.makeText(this, "Updated setlist: $newName", Toast.LENGTH_SHORT).show()
                    dialog.dismiss(); showSavedSetlists()
                }
            }
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.96).toInt(), (resources.displayMetrics.heightPixels * 0.88).toInt())
        }
        dialog.setOnDismissListener {
            if (remoteNavigationDialog === dialog) {
                remoteNavigationDialog = null
                remoteNavigationRoot = null
            }
        }
        dialog.show()
    }

    private fun loadSavedSetlist(name: String) {
        val stored = setlistPrefs.getString("setlist:$name", null)
        if (stored.isNullOrBlank()) {
            Toast.makeText(this, "That saved setlist is empty.", Toast.LENGTH_LONG).show()
            showSavedSetlists()
            return
        }
        Toast.makeText(this, "Loading setlist…", Toast.LENGTH_SHORT).show()
        Thread {
            val loaded = mutableListOf<Song>()
            val missing = mutableListOf<String>()
            stored.split("\n").filter { it.isNotBlank() }.forEach { storedUri ->
                try {
                    if (storedUri.startsWith("https://", true)) {
                        val text = fetchText(storedUri)
                        val fileName = storedUri.substringBefore('?').substringAfterLast('/').ifBlank { "Online Song.txt" }
                        if (text.isNotBlank()) loaded.add(Song(Uri.parse(storedUri), displaySongName(fileName), text)) else missing.add(displaySongName(fileName))
                    } else {
                        val file = java.io.File(Uri.parse(storedUri).path ?: storedUri)
                        if (file.isFile && file.extension.equals("txt", true) && file.canRead()) {
                            val text = file.readText(Charsets.UTF_8)
                            if (text.isNotBlank()) loaded.add(Song(Uri.fromFile(file), displaySongName(file.name), text)) else missing.add(displaySongName(file.name) + " (empty)")
                        } else missing.add(displaySongName(file.name))
                    }
                } catch (_: Exception) { missing.add(storedUri.substringBefore('?').substringAfterLast('/')) }
            }
            runOnUiThread {
                if (loaded.isEmpty()) {
                    AlertDialog.Builder(this).setTitle("Could not load setlist")
                        .setMessage("The saved setlist '$name' has no readable lyric files. Check your internet connection or whether files were moved.")
                        .setPositiveButton("OK") { _, _ -> showSavedSetlists() }.showWithPhoneRemote()
                } else if (missing.isNotEmpty()) {
                    AlertDialog.Builder(this).setTitle("Some songs unavailable")
                        .setMessage("These songs could not be loaded:\n\n${missing.joinToString("\n")}\n\nThe available songs will be loaded.")
                        .setPositiveButton("Continue") { _, _ -> addHistoryEntry("setlist", name, name); showGigOverview(name, loaded) }
                        .setNegativeButton("Cancel") { _, _ -> showSavedSetlists() }.showWithPhoneRemote()
                } else { addHistoryEntry("setlist", name, name); showGigOverview(name, loaded) }
            }
        }.start()
    }

    /** Dedicated pre-show overview. It reuses the existing saved-setlist editor and queue engine. */
    private fun showGigOverview(name: String, songs: MutableList<Song>) {
        inViewer = false
        inBrowser = false
        inSavedSetlists = false
        inRecentHistory = false
        inOnlineLyrics = false
        isCountdownScreen = false
        handler.removeCallbacks(tick)
        val root = verticalLayout()
        root.addView(makeText("GIG OVERVIEW", 28f, Color.rgb(255, 202, 32), true).apply {
            gravity = Gravity.CENTER
            setPadding(8, 4, 8, 4)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        root.addView(makeText(name, 24f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            maxLines = 2
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        root.addView(makeText("${songs.size} songs  •  ${queueDelaySeconds}s between songs", 16f, Color.LTGRAY).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val note = notesPrefs.getString("setlist_note:$name", "")?.trim().orEmpty()
        if (note.isNotBlank()) {
            val notePanel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = buttonSurface(Color.rgb(20, 28, 39), Color.rgb(92, 82, 48))
            }
            notePanel.addView(makeText("SETLIST NOTES", 14f, Color.rgb(255, 202, 32), true))
            notePanel.addView(makeText(note, 16f, Color.WHITE).apply { maxLines = 4 })
            root.addView(notePanel, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }

        root.addView(makeText("RUNNING ORDER", 15f, Color.rgb(255, 202, 32), true),
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        songs.forEachIndexed { index, song ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(4), dp(10), dp(4))
                background = buttonSurface(Color.rgb(20, 28, 39), Color.rgb(53, 65, 80))
            }
            row.addView(makeText("${index + 1}.", 17f, Color.rgb(255, 202, 32), true),
                LinearLayout.LayoutParams(responsiveDp(42, 34), responsiveDp(56, 46)))
            row.addView(makeText(song.name, 17f, Color.WHITE).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END },
                LinearLayout.LayoutParams(0, responsiveDp(56, 46), 1f))
            list.addView(row, LinearLayout.LayoutParams(-1, responsiveDp(66, 52)).apply { bottomMargin = dp(5) })
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { bottomMargin = dp(10) })

        fun action(label: String, onClick: () -> Unit): Button = Button(this).apply {
            text = label
            styleButton(this)
            setOnClickListener { onClick() }
        }
        root.addView(action("START GIG", {
            queue = songs.toMutableList()
            lastLoadedQueue = songs.toMutableList()
            currentSetlistName = name
            currentSongIndex = 0
            isQueueMode = queue.size > 1
            repeatSingleSongUntilBack = false
            startLoadedQueue(queue.toMutableList(), name)
        }), LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { bottomMargin = dp(8) })
        root.addView(action("EDIT SETLIST", { editSavedSetlist(name) }),
            LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { bottomMargin = dp(8) })
        root.addView(action("BACK TO SETLISTS", { showSavedSetlists() }),
            LinearLayout.LayoutParams(-1, responsiveDp(68, 48)))
        setContentView(root)
        root.post { findFirstFocusable(root)?.requestFocus() }
    }

    private data class GitHubLocation(val owner: String, val repo: String, val branch: String, val path: String)

    private fun parseGitHubLocation(input: String): GitHubLocation {
        // Users often paste a URL copied without the scheme, or with a trailing slash.
        // Normalize those common forms before validating so a browser-valid GitHub URL
        // is not rejected simply because it was pasted in a shortened form.
        var address = input.trim()
        // If a link is pasted as Markdown, use the target URL rather than its label.
        val markdownTarget = Regex("\\]\\((https?://[^)]+)\\)").find(address)?.groupValues?.getOrNull(1)
        if (!markdownTarget.isNullOrBlank()) address = markdownTarget
        address = address.trim().trim('<', '>').trimEnd('/')
        require(address.isNotBlank()) {
            "Enter a public GitHub repository or folder URL."
        }
        if (address.startsWith("www.github.com/", ignoreCase = true)) address = "https://$address"
        else if (address.startsWith("github.com/", ignoreCase = true)) address = "https://$address"
        else if (address.startsWith("http://", ignoreCase = true)) address = "https://${address.substring(7)}"
        else if (!address.startsWith("https://", ignoreCase = true)) address = "https://$address"

        val uri = Uri.parse(address)
        require(uri.scheme.equals("https", true) &&
                (uri.host.equals("github.com", true) || uri.host.equals("www.github.com", true))) {
            "Use a public GitHub URL such as https://github.com/owner/repository or https://github.com/owner/repository/tree/main/lyrics."
        }
        val parts = uri.pathSegments.filter { it.isNotBlank() }
        require(parts.size >= 2) {
            "The GitHub URL must include an owner and repository, for example https://github.com/owner/repository."
        }
        val owner = parts[0]
        val repo = parts[1].removeSuffix(".git")
        require(owner.isNotBlank() && repo.isNotBlank()) { "The GitHub URL must include an owner and repository." }

        if (parts.size >= 4 && (parts[2] == "tree" || parts[2] == "blob")) {
            val branch = parts[3]
            val pathParts = parts.drop(4)
            // If a single-file GitHub page was pasted, browse its containing folder.
            val folderParts = if (parts[2] == "blob" && pathParts.isNotEmpty()) pathParts.dropLast(1) else pathParts
            return GitHubLocation(owner, repo, branch, folderParts.joinToString("/"))
        }
        return GitHubLocation(owner, repo, "", "")
    }

    private fun fetchText(address: String): String {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 12000
        connection.readTimeout = 15000
        connection.setRequestProperty("User-Agent", "DPH-Gig-Assistant-TV")
        connection.setRequestProperty("Accept", "application/vnd.github+json, text/plain, */*")
        try {
            val code = connection.responseCode
            if (code !in 200..299) {
                val errorStream = connection.errorStream
                val body = try { errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } } catch (_: Exception) { null }
                val detail = try { if (!body.isNullOrBlank()) JSONObject(body).optString("message", body) else "" } catch (_: Exception) { body ?: "" }
                throw IllegalStateException("GitHub returned HTTP $code${if (detail.isBlank()) "" else ": $detail"}")
            }
            return connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { connection.disconnect() }
    }

    private fun githubApiUrl(location: GitHubLocation): String {
        val branch = if (location.branch.isBlank()) {
            val meta = JSONObject(fetchText("https://api.github.com/repos/${location.owner}/${location.repo}"))
            meta.optString("default_branch", "main")
        } else location.branch
        val path = if (location.path.isBlank()) "" else "/" + Uri.encode(location.path).replace("%2F", "/")
        return "https://api.github.com/repos/${location.owner}/${location.repo}/contents$path?ref=${Uri.encode(branch)}"
    }

    private fun refreshOnlineSelectedCount() {
        onlineUseSelectedButtons.forEach { it.text = "PLAY SELECTED (${onlineSelected.size})" }
    }

    private fun makeUseSelectedSongsButton(height: Int = 78): Button = Button(this).apply {
        text = "PLAY SELECTED (${onlineSelected.size})"
        styleButton(this)
        textSize = 17f
        maxLines = 2
        setPadding(12, 8, 12, 8)
        onlineUseSelectedButtons.add(this)
        setOnClickListener {
            if (onlineSelected.isEmpty()) {
                Toast.makeText(this@MainActivity, "Select one or more .txt songs first.", Toast.LENGTH_SHORT).show()
            } else if (onlineSelected.values.any { it.text.isBlank() }) {
                Toast.makeText(this@MainActivity, "Still downloading selected lyrics. Please wait a moment.", Toast.LENGTH_SHORT).show()
            } else {
                lastLoadedQueue = onlineSelected.values.toMutableList()
                queue = lastLoadedQueue.toMutableList()
                currentSongIndex = 0
                isQueueMode = queue.size > 1
                val returnAddress = onlineRootUrl ?: ""
                val returnPath = onlineCurrentPath
                confirmQueue {
                    if (returnAddress.isNotBlank()) loadGitHubFolder(returnAddress, returnPath)
                    else showOnlineLocations()
                }
            }
        }
        layoutParams = LinearLayout.LayoutParams(-1, height).apply { topMargin = 8 }
    }

    private fun showOnlineLocations() {
        onlineUseSelectedButtons.clear()
        onlineRootUrl = null
        onlineCurrentPath = ""
        inViewer = false; inBrowser = false; inSavedSetlists = false; inOnlineLyrics = true
        isCountdownScreen = false; handler.removeCallbacks(tick)
        val root = verticalLayout().apply { setPadding(28, 18, 28, 22) }
        root.addView(makeText("Online Lyrics", 25f, Color.rgb(255, 205, 35), true).apply { gravity = Gravity.CENTER; setPadding(8, 8, 8, 8); includeFontPadding = true; maxLines = 2 }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        root.addView(makeText("Browse public GitHub lyric folders. Your saved connections stay on this device.", 17f, Color.LTGRAY).apply { gravity = Gravity.CENTER; setPadding(4, 4, 4, 8); maxLines = 4 }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list, LinearLayout.LayoutParams(-1, -2))
        fun actionButton(label: String, action: () -> Unit) {
            list.addView(Button(this).apply { text = label; styleButton(this); gravity = Gravity.CENTER; setOnClickListener { action() } }, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { bottomMargin = dp(8) })
        }
        actionButton("+ Add GitHub Location") { promptAddOnlineLocation() }
        actionButton("Browse Community Libraries") {
            AlertDialog.Builder(this@MainActivity).setTitle("Community Libraries")
                .setMessage("Community libraries are public GitHub lyric folders shared by musicians. Add a library URL to make it available here. A centrally hosted DPH library can be added once its public repository is established.")
                .setPositiveButton("Add a library") { _, _ -> promptAddOnlineLocation() }
                .setNegativeButton("Close", null).showWithPhoneRemote()
        }
        actionButton("Saved Connections") { showSavedOnlineConnections() }
        root.addView(Button(this).apply { text = "Back to Browse Files"; styleButton(this); gravity = Gravity.CENTER; setOnClickListener { inOnlineLyrics = false; onlineRootUrl = null; showFileBrowser() } }, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { topMargin = dp(6) })
        val pageScroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        setContentView(pageScroll)
        list.getChildAt(0)?.requestFocus()
    }

    private fun showSavedOnlineConnections() {
        inOnlineLyrics = true
        val root = verticalLayout().apply { setPadding(28, 18, 28, 22) }
        root.addView(makeText("Saved Connections", 26f, Color.rgb(255, 205, 35), true).apply { gravity = Gravity.CENTER; setPadding(8, 8, 8, 12) }, LinearLayout.LayoutParams(-1, -2))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list, LinearLayout.LayoutParams(-1, -2))
        val locations = onlinePrefs.all.keys.filter { it.startsWith("location:") }.sortedBy { it.removePrefix("location:").lowercase(Locale.ROOT) }
        if (locations.isEmpty()) {
            list.addView(makeText("No saved connections yet. Choose Add GitHub Location to add one.", 18f, Color.LTGRAY).apply { gravity = Gravity.CENTER; setPadding(8, 18, 8, 18) }, LinearLayout.LayoutParams(-1, -2))
        }
        locations.forEach { key ->
            val label = key.removePrefix("location:")
            val open = Button(this).apply {
                text = label; styleButton(this); gravity = Gravity.CENTER; maxLines = 2; setOnClickListener { browseGitHubLocation(onlinePrefs.getString(key, "") ?: "") }
            }
            list.addView(open, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { bottomMargin = dp(6) })
            val edit = Button(this).apply {
                text = "Edit"; styleButton(this); gravity = Gravity.CENTER; textSize = 18f; maxLines = 1
                setOnClickListener { editOnlineConnection(label, onlinePrefs.getString(key, "") ?: "") }
            }
            list.addView(edit, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { bottomMargin = dp(6) })
            val delete = Button(this).apply {
                text = "Remove"; styleButton(this); gravity = Gravity.CENTER; textSize = 18f; maxLines = 1
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle("Remove '$label'?").setMessage("This removes the saved online location from this device.").setNegativeButton("Cancel", null).setPositiveButton("Remove") { _, _ -> onlinePrefs.edit().remove(key).apply(); showSavedOnlineConnections() }.showWithPhoneRemote()
                }
            }
            list.addView(delete, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { bottomMargin = dp(14) })
        }
        root.addView(Button(this).apply { text = "Back to Online Lyrics"; styleButton(this); gravity = Gravity.CENTER; setOnClickListener { showOnlineLocations() } }, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { topMargin = dp(8) })
        root.addView(Button(this).apply { text = "Back to Browse Files"; styleButton(this); gravity = Gravity.CENTER; setOnClickListener { inOnlineLyrics = false; onlineRootUrl = null; showFileBrowser() } }, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { topMargin = dp(6) })
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        setContentView(scroll)
        list.getChildAt(0)?.requestFocus()
    }

    private fun editOnlineConnection(oldName: String, oldAddress: String) {
        val nameInput = EditText(this).apply {
            setText(oldName); hint = "Connection name"; setSingleLine(true); textSize = 17f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setPadding(20, 14, 20, 14)
        }
        val urlInput = EditText(this).apply {
            setText(oldAddress); hint = "Public GitHub repository or folder URL"; setSingleLine(true); textSize = 17f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setPadding(20, 14, 20, 14)
        }
        val fields = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 4, 8, 4); addView(nameInput); addView(urlInput) }
        AlertDialog.Builder(this).setTitle("Edit Online Connection").setMessage("Change the display name or GitHub folder URL.").setView(fields)
            .setNegativeButton("Cancel", null).setPositiveButton("Save", null).create().also { dialog ->
                dialog.setOnShowListener {
                    remoteNavigationDialog = dialog
                    remoteNavigationRoot = dialog.window?.decorView
                    nameInput.requestFocus()
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val newName = nameInput.text.toString().trim()
                        val newAddress = urlInput.text.toString().trim().trimEnd('/')
                        try {
                            require(newName.isNotBlank()) { "Enter a name for this connection." }
                            parseGitHubLocation(newAddress)
                            if (newName != oldName && onlinePrefs.contains("location:$newName"))
                                throw IllegalArgumentException("A connection with that name already exists.")
                            val editor = onlinePrefs.edit()
                            if (newName != oldName) editor.remove("location:$oldName")
                            editor.putString("location:$newName", newAddress).apply()
                            dialog.dismiss()
                            showSavedOnlineConnections()
                        } catch (e: Exception) {
                            AlertDialog.Builder(this@MainActivity).setTitle("Unable to save connection")
                                .setMessage(e.message ?: "Check the connection name and URL.").setPositiveButton("OK", null).showWithPhoneRemote()
                        }
                    }
                }
                dialog.setOnDismissListener {
                    if (remoteNavigationDialog === dialog) { remoteNavigationDialog = null; remoteNavigationRoot = null }
                }
                dialog.show()
            }
    }

    private fun promptAddOnlineLocation() {
        val urlInput = EditText(this).apply { hint = "https://github.com/owner/repo/tree/main/lyrics"; setSingleLine(true); textSize = 17f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setPadding(20, 14, 20, 14) }
        val nameInput = EditText(this).apply { hint = "Location name (e.g. My Country Lyrics)"; setSingleLine(true); textSize = 17f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setPadding(20, 14, 20, 14) }
        val fields = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 4, 8, 4); addView(nameInput); addView(urlInput) }
        AlertDialog.Builder(this).setTitle("Add Online Lyrics Location").setMessage("Use a public GitHub repository or folder URL.").setView(fields)
            .setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val name = nameInput.text.toString().trim(); val address = urlInput.text.toString().trim().trimEnd('/')
                try {
                    require(name.isNotBlank()) { "Enter a name for this location." }
                    parseGitHubLocation(address)
                    onlinePrefs.edit().putString("location:$name", address).apply()
                    browseGitHubLocation(address)
                } catch (e: Exception) { AlertDialog.Builder(this).setTitle("Invalid GitHub location").setMessage(e.message ?: "Please check the URL.").setPositiveButton("OK") { _, _ -> showOnlineLocations() }.showWithPhoneRemote() }
            }.showWithPhoneRemote()
    }

    private fun browseGitHubLocation(address: String) {
        inOnlineLyrics = true
        onlineRootUrl = address
        onlineCurrentPath = ""
        loadGitHubFolder(address, "")
    }

    private fun loadGitHubFolder(rootAddress: String, subPath: String) {
        onlineUseSelectedButtons.clear()
        onlineRootUrl = rootAddress; onlineCurrentPath = subPath; inOnlineLyrics = true
        val location = try { parseGitHubLocation(rootAddress) } catch (e: Exception) { Toast.makeText(this, e.message, Toast.LENGTH_LONG).show(); showOnlineLocations(); return }
        val folderPath = listOf(location.path, subPath).filter { it.isNotBlank() }.joinToString("/")
        val root = verticalLayout().apply { setPadding(28, 18, 28, 22) }
        root.addView(makeText("Online Lyrics", 24f, Color.rgb(255, 205, 35), true).apply { gravity = Gravity.CENTER; maxLines = 2; setPadding(8, 8, 8, 8); includeFontPadding = true }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6 })
        root.addView(makeText("${location.owner}/${location.repo}${if (folderPath.isBlank()) "" else "/$folderPath"}", 16f, Color.LTGRAY).apply { maxLines = 5; setPadding(4, 4, 4, 8) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6 })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list, LinearLayout.LayoutParams(-1, -2))
        root.addView(makeUseSelectedSongsButton(82))
        root.addView(Button(this).apply { text = "Saved Locations"; styleButton(this); setOnClickListener { showOnlineLocations() } }, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { topMargin = dp(6) })
        root.addView(Button(this).apply { text = "Back to Browse Files"; styleButton(this); setOnClickListener { inOnlineLyrics = false; onlineRootUrl = null; showFileBrowser() } }, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { topMargin = dp(6) })
        val pageScroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        setContentView(pageScroll)
        list.addView(makeText("Connecting to GitHub…", 18f, Color.LTGRAY), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12; bottomMargin = 12 })
        Thread {
            try {
                val apiUrl = githubApiUrl(location.copy(path = folderPath))
                val response = JSONArray(fetchText(apiUrl))
                val items = (0 until response.length()).map { response.getJSONObject(it) }.sortedWith(compareBy<JSONObject> { if (it.optString("type") == "dir") 0 else 1 }.thenBy { it.optString("name").lowercase(Locale.ROOT) })
                runOnUiThread {
                    list.removeAllViews()
                    if (subPath.isNotBlank()) {
                        val parent = subPath.substringBeforeLast('/', "")
                        list.addView(Button(this).apply { text = "↑ .. (Parent folder)"; styleButton(this); setOnClickListener { loadGitHubFolder(rootAddress, parent) } }, LinearLayout.LayoutParams(-1, responsiveDp(68, 48)).apply { bottomMargin = dp(6) })
                    }
                    items.filter { it.optString("type") == "dir" || it.optString("name").endsWith(".txt", true) }.forEach { item ->
                        val itemName = item.optString("name")
                        val path = item.optString("path")
                        if (item.optString("type") == "dir") {
                            val folderButton = Button(this).apply {
                                text = "📁  $itemName"
                                styleButton(this)
                                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                                maxLines = 3
                                minHeight = responsiveDp(72, 54)
                                setOnClickListener {
                                    val base = location.path
                                    val relative = path.removePrefix(if (base.isBlank()) "" else "$base/")
                                    loadGitHubFolder(rootAddress, relative)
                                }
                            }
                            list.addView(folderButton, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6 })
                        } else {
                            val raw = item.optString("download_url")
                            val key = raw
                            val initiallySelected = onlineSelected.containsKey(key)
                            val row = LinearLayout(this).apply {
                                orientation = LinearLayout.HORIZONTAL
                                gravity = Gravity.CENTER_VERTICAL
                                setPadding(6, 2, 6, 2)
                                background = buttonSurface(if (initiallySelected) Color.rgb(74, 62, 20) else Color.rgb(18, 24, 32))
                            }
                            val check = CheckBox(this).apply {
                                text = displaySongName(itemName)
                                textSize = 17f
                                setTextColor(Color.WHITE)
                                isChecked = initiallySelected
                                maxLines = 3
                                minHeight = responsiveDp(76, 58)
                                setPadding(10, 8, 10, 8)
                                setOnFocusChangeListener { _, hasFocus ->
                                    row.background = buttonSurface(
                                        when {
                                            hasFocus -> Color.rgb(255, 202, 32)
                                            isChecked -> Color.rgb(74, 62, 20)
                                            else -> Color.rgb(18, 24, 32)
                                        },
                                        if (hasFocus) Color.rgb(255, 225, 105) else Color.rgb(65, 75, 88)
                                    )
                                    setTextColor(if (hasFocus) Color.BLACK else Color.WHITE)
                                }
                                setOnCheckedChangeListener { _, checked ->
                                    if (checked) {
                                        // Count the selection immediately, then replace the placeholder when download completes.
                                        onlineSelected[key] = Song(Uri.parse(raw), displaySongName(itemName), "")
                                        text = "✓ ${displaySongName(itemName)}"
                                        row.background = buttonSurface(Color.rgb(74, 62, 20))
                                        refreshOnlineSelectedCount()
                                        Thread {
                                            try {
                                                val lyrics = fetchText(raw)
                                                runOnUiThread {
                                                    if (onlineSelected.containsKey(key)) {
                                                        onlineSelected[key] = Song(Uri.parse(raw), displaySongName(itemName), lyrics)
                                                        refreshOnlineSelectedCount()
                                                    }
                                                }
                                            } catch (e: Exception) {
                                                runOnUiThread {
                                                    onlineSelected.remove(key)
                                                    isChecked = false
                                                    refreshOnlineSelectedCount()
                                                    Toast.makeText(this@MainActivity, "Could not download $itemName: ${e.message}", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }.start()
                                    } else {
                                        onlineSelected.remove(key)
                                        text = displaySongName(itemName)
                                        row.background = buttonSurface(Color.rgb(18, 24, 32))
                                        refreshOnlineSelectedCount()
                                    }
                                }
                            }
                            row.addView(check, LinearLayout.LayoutParams(-1, -2))
                            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6 })
                        }
                    }
                    if (list.childCount == 0) list.addView(makeText("No folders or .txt lyric files found here.", 18f, Color.LTGRAY), LinearLayout.LayoutParams(-1, 70))
                    list.getChildAt(0)?.requestFocus()
                }
            } catch (e: Exception) {
                runOnUiThread { list.removeAllViews(); list.addView(makeText("Unable to browse this location. Check that it is public and the URL points to a repository or folder.\n\n${e.message}", 17f, Color.LTGRAY), LinearLayout.LayoutParams(-1, -2)); list.requestFocus() }
            }
        }.start()
    }

    private fun confirmQueue(onCancel: () -> Unit = { showHome() }) {
        val previousRemoteDialog = remoteNavigationDialog
        val previousRemoteRoot = remoteNavigationRoot
        val selectedQueue = queue.toMutableList()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 8, 18, 8)
            setBackgroundColor(Color.rgb(10, 14, 20))
        }
        layout.addView(makeText("Review playback order. Use the arrows to move songs before starting.", 16f, Color.LTGRAY),
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        layout.addView(makeText("${selectedQueue.size} song(s)  •  ${queueDelaySeconds}s between songs", 17f, Color.rgb(255, 205, 35), true),
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        val scroll = ScrollView(this)
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(rows)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        var focusIndexAfterMove = -1
        var focusDirectionAfterMove = ""
        var focusTargetAfterRender: View? = null
        fun renderRows() {
            rows.removeAllViews()
            focusTargetAfterRender = null
            selectedQueue.forEachIndexed { index, song ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                row.addView(makeText("${index + 1}. ${song.name}", 17f, Color.WHITE).apply { maxLines = 2 },
                    LinearLayout.LayoutParams(0, 66, 1f).apply { rightMargin = 8 })
                fun moveButton(label: String, enabled: Boolean, direction: String): Button = Button(this).apply {
                    text = label; styleButton(this); textSize = 14f; isEnabled = enabled
                    alpha = if (enabled) 1f else 0.35f; setPadding(4, 4, 4, 4); minHeight = 56
                    if (index == focusIndexAfterMove && direction == focusDirectionAfterMove) focusTargetAfterRender = this
                    setOnClickListener {
                        if (!enabled) return@setOnClickListener
                        val targetIndex = if (direction == "up") index - 1 else index + 1
                        selectedQueue.add(targetIndex, selectedQueue.removeAt(index))
                        focusIndexAfterMove = targetIndex
                        focusDirectionAfterMove = direction
                        renderRows()
                        // The old button was removed with the previous row tree. Wait until
                        // Android lays out the replacement rows, then focus the matching arrow.
                        rows.post {
                            focusTargetAfterRender?.let { target ->
                                target.requestFocus()
                                target.requestFocusFromTouch()
                            }
                        }
                    }
                }
                row.addView(moveButton("▲", index > 0, "up"),
                    LinearLayout.LayoutParams(68, 60).apply { rightMargin = 5 })
                row.addView(moveButton("▼", index < selectedQueue.lastIndex, "down"),
                    LinearLayout.LayoutParams(68, 60))
                rows.addView(row)
            }
        }
        renderRows()
        val dialog = AlertDialog.Builder(this)
            .setTitle("Review Selected Songs")
            .setView(layout)
            .setPositiveButton("PLAY QUEUE", null)
            .setNegativeButton("CANCEL", null)
            .create()
        dialog.setOnShowListener {
            // Route phone navigation to this review dialog, not the file browser behind it.
            remoteNavigationDialog = dialog
            remoteNavigationRoot = dialog.window?.decorView
            // Start focus inside the dialog, on the first move control when possible.
            val firstArrow = rows.getChildAt(0)?.let { row ->
                (row as? android.view.ViewGroup)?.getChildAt(1)
            }
            (firstArrow ?: dialog.getButton(AlertDialog.BUTTON_POSITIVE))?.post {
                if (firstArrow?.isShown == true) firstArrow.requestFocus()
                else dialog.getButton(AlertDialog.BUTTON_POSITIVE).requestFocus()
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (selectedQueue.isEmpty()) {
                    Toast.makeText(this, "Select at least one song.", Toast.LENGTH_SHORT).show()
                } else {
                    queue = selectedQueue.toMutableList()
                    lastLoadedQueue = selectedQueue.toMutableList()
                    dialog.dismiss()
                    startLoadedQueue(selectedQueue.toMutableList())
                }
            }
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener { dialog.dismiss(); onCancel() }
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), (resources.displayMetrics.heightPixels * 0.88).toInt())
        }
        dialog.setOnCancelListener {
            if (remoteNavigationDialog === dialog) {
                remoteNavigationDialog = previousRemoteDialog?.takeIf { it.isShowing }
                remoteNavigationRoot = remoteNavigationDialog?.window?.decorView
                    ?: previousRemoteRoot?.takeIf { it.isShown }
            }
            onCancel()
        }
        dialog.setOnDismissListener {
            if (remoteNavigationDialog === dialog) {
                remoteNavigationDialog = previousRemoteDialog?.takeIf { it.isShowing }
                remoteNavigationRoot = remoteNavigationDialog?.window?.decorView
                    ?: previousRemoteRoot?.takeIf { it.isShown }
            }
        }
        dialog.setCancelable(true)
        dialog.show()
    }

    private fun playCurrent() {
        isCountdownScreen = false
        inBrowser = false
        if (currentSongIndex !in queue.indices) { showHome("Queue finished."); return }
        inViewer = true
        paused = false
        endHandled = false
        scrollAccumulator = 0.0
        lastTick = 0L
        val song = queue[currentSongIndex]
        addHistoryEntry("song", song.name, song.uri.toString())
        loadSongPlaybackSettings(song)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); isFocusable = true; isFocusableInTouchMode = true }
        viewport = root
        val content = TextView(this).apply {
            text = song.text
            textSize = fontSp
            setTextColor(Color.WHITE)
            typeface = Typeface.create("monospace", Typeface.NORMAL)
            setLineSpacing(8f, 1.05f)
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            setPadding(100, 18, 100, 140)
            isFocusable = true
            isFocusableInTouchMode = true
            // Make the active lyrics area obvious when navigating with a TV remote.
            background = buttonSurface(Color.TRANSPARENT, Color.TRANSPARENT)
            setOnFocusChangeListener { view, hasFocus ->
                view.background = if (hasFocus) {
                    buttonSurface(Color.TRANSPARENT, Color.rgb(255, 202, 32))
                } else {
                    buttonSurface(Color.TRANSPARENT, Color.TRANSPARENT)
                }
            }
            setOnClickListener { requestFocus() }
        }
        scrollText = content
        root.addView(content, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        // FrameLayout can measure a WRAP_CONTENT child with the viewport's height
        // as its maximum, which clips long lyrics. Explicitly measure the TextView
        // with an UNSPECIFIED height so it contains the entire song, then keep that
        // full height updated whenever the font size changes.
        val performanceBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(17, 21, 28))
            // Inset the entire footer from TV overscan; some televisions crop edge pixels.
            setPadding(18, 8, 18, 8)
        }
        val statusBar = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER_VERTICAL
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setPadding(14, 6, 14, 6)
            setLineSpacing(3f, 1.0f)
            includeFontPadding = true
            maxLines = 6
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        status = statusBar
        performanceBar.addView(statusBar, LinearLayout.LayoutParams(0, -2, 1f))
        val micButton = Button(this).apply {
            text = "🎙 Speak"
            textSize = 15f
            isAllCaps = false
            setTextColor(Color.BLACK)
            background = buttonSurface(Color.rgb(255, 202, 32), Color.rgb(255, 225, 105))
            minHeight = 52
            minWidth = 108
            setPadding(12, 8, 12, 8)
            isFocusable = true
            isFocusableInTouchMode = true
            // TV remotes need a strong focus indicator so the microphone is easy to find.
            setOnFocusChangeListener { view, hasFocus ->
                val button = view as Button
                if (hasFocus) {
                    button.background = buttonSurface(Color.rgb(255, 225, 105), Color.WHITE)
                    button.setTextColor(Color.BLACK)
                } else {
                    button.background = buttonSurface(Color.rgb(255, 202, 32), Color.rgb(255, 225, 105))
                    button.setTextColor(Color.BLACK)
                }
            }
            setOnClickListener { startPushToTalk() }
        }
        voiceButton = micButton
        performanceBar.addView(micButton, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = 8 })
        val modeButton = Button(this).apply {
            text = if (performanceModeEnabled) "Performance ON" else "Performance OFF"
            textSize = 13f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = buttonSurface(Color.rgb(38, 45, 55), Color.rgb(95, 108, 124))
            minHeight = 52
            minWidth = 148
            setPadding(14, 6, 14, 6)
            isFocusable = true
            isFocusableInTouchMode = true
            setOnFocusChangeListener { view, hasFocus ->
                val button = view as Button
                button.background = buttonSurface(
                    if (hasFocus) Color.rgb(62, 58, 34) else Color.rgb(38, 45, 55),
                    if (hasFocus) Color.rgb(255, 225, 105) else Color.rgb(95, 108, 124)
                )
                button.setTextColor(if (hasFocus) Color.rgb(255, 225, 105) else Color.WHITE)
            }
            setOnClickListener {
                if (!hasProFeatureAccess(ProFeature.PERFORMANCE_MODE)) {
                    showProFeatureRequired("Performance Mode")
                    return@setOnClickListener
                }
                performanceModeEnabled = !performanceModeEnabled
                text = if (performanceModeEnabled) "Performance ON" else "Performance OFF"
                updateStatus()
            }
        }
        performanceButton = modeButton
        performanceBar.addView(modeButton, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = 6 })
        // Keep playback controls visible for both TV remotes and phone touch.
        root.addView(performanceBar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            leftMargin = 28
            rightMargin = 28
            bottomMargin = 10
        })
        setContentView(root)
        updateStatus()
        content.post {
            measureFullLyricsHeight()
            scrollYFloat = root.height.toFloat() + 20f
            content.translationY = scrollYFloat
            lastTick = System.nanoTime()
            handler.removeCallbacks(tick)
            handler.post(tick)
            root.requestFocus()
        }
    }

    private fun showProUpgrade() {
        val tier = if (isProEntitled()) "PRO (TEST MODE)" else "FREE (TEST MODE)"
        val message = "GIG ASSISTANT PRO\nYOUR SETLIST. YOUR STAGE.\n\nFREE INCLUDES\n• Local .txt lyrics and saved setlists\n• Manual scrolling speed and font controls\n• Voice commands and playback controls\n• Online Lyrics browsing and saved online locations\n\nPRO INCLUDES (PREVIEW)\n• Per-song speed and font settings\n• Performance Mode with current/next-song information\n• Future advanced setlist tools\n\nCURRENT STATUS: $tier\n\nSimulate Free and Simulate Pro actively switch feature access and update the Home screen badge. Purchases are not enabled yet. This is development testing only: no payment is taken, and selecting Pro here does not represent a real purchase."
        AlertDialog.Builder(this)
            .setTitle("Gig Assistant Pro")
            .setMessage(message)
            .setNeutralButton("Simulate Free") { _, _ ->
                entitlementPrefs.edit().putString("testing_tier", "free").apply()
                performanceModeEnabled = false
                Toast.makeText(this, "Free test tier selected", Toast.LENGTH_SHORT).show()
                showHome()
            }
            .setPositiveButton("Simulate Pro") { _, _ ->
                entitlementPrefs.edit().putString("testing_tier", "pro").apply()
                performanceModeEnabled = true
                Toast.makeText(this, "Pro test tier selected — Performance Mode will start ON", Toast.LENGTH_SHORT).show()
                showHome()
            }
            .setNegativeButton("Close", null)
            .showWithPhoneRemote()
    }

    private fun measureFullLyricsHeight() {
        val root = viewport ?: return
        val content = scrollText ?: return
        val availableWidth = root.width
        if (availableWidth <= 0) return
        content.measure(
            View.MeasureSpec.makeMeasureSpec(availableWidth, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val lp = content.layoutParams as? FrameLayout.LayoutParams ?: return
        if (lp.height != content.measuredHeight) {
            lp.height = content.measuredHeight
            content.layoutParams = lp
        }
    }

    private fun updateStatus() {
        val state = if (paused) "PAUSED" else "PLAYING"
        val repeatLabel = if (repeatCurrentSong) "   •   REPEAT ON" else ""
        val songName = queue.getOrNull(currentSongIndex)?.name ?: ""
        val nextName = queue.getOrNull(currentSongIndex + 1)?.name
        val voice = voiceStatusMessage?.let { "\n$it" } ?: ""
        status?.text = if (performanceModeEnabled) {
            val nextLine = if (nextName == null) "LAST SONG IN SET" else "NEXT UP: $nextName"
            val currentSong = queue.getOrNull(currentSongIndex)
            val songNote = currentSong?.let { notesPrefs.getString("song_note:${it.uri}", "")?.trim() }.orEmpty()
            val setlistNote = currentSetlistName?.let { notesPrefs.getString("setlist_note:$it", "")?.trim() }.orEmpty()
            val songNoteLine = if (songNote.isNotBlank()) "SONG NOTES: $songNote" else ""
            val setlistNoteLine = if (setlistNote.isNotBlank()) "SETLIST NOTES: $setlistNote" else ""
            listOf(
                songName,
                "$state$repeatLabel   •   ${currentSongIndex + 1}/${queue.size}   •   Speed ${String.format(Locale.US, "%.2f", speedSteps[speedIndex])}   •   Font ${fontSp.toInt()}",
                songNoteLine,
                nextLine,
                setlistNoteLine,
                voice.trimStart('\n')
            ).filter { it.isNotBlank() }.joinToString("\n")
        } else {
            val controls = if (resources.configuration.smallestScreenWidthDp < 600) {
                "Tap 🎙 Speak for voice commands"
            } else {
                "OK Pause/Resume   •   ◀ ▶ Speed   •   ▲ ▼ Font   •   BACK Next Up / Menu"
            }
            "$state$repeatLabel   •   Speed ${String.format(Locale.US, "%.2f", speedSteps[speedIndex])}   •   Font ${fontSp.toInt()}   •   ${currentSongIndex + 1}/${queue.size}   •   $songName\n$controls$voice"
        }
        status?.textSize = if (performanceModeEnabled) 16f else 13f
    }

    private fun startPushToTalk() {
        if (!inViewer) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            voiceStatusMessage = "Microphone permission needed. Android should ask you to allow it."
            updateStatus()
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC_PERMISSION)
            return
        }
        launchSpeechRecognition()
    }

    // Use SpeechRecognizer directly. Do not launch ACTION_RECOGNIZE_SPEECH as an
    // Activity: on some phones that opens Google Assistant, which responds
    // "Sorry, I can't do this on this app" instead of returning recognized text.
    private fun launchSpeechRecognition() {
        if (!inViewer) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            voiceStatusMessage = "Microphone permission is required. Tap Speak and allow it when prompted."
            updateStatus()
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC_PERMISSION)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            voiceButton?.text = "🎙 Speak"
            voiceStatusMessage = "No speech-recognition service is available. Enable Google voice typing or another recognition service in phone settings."
            updateStatus()
            Toast.makeText(this, "Speech recognition service unavailable", Toast.LENGTH_LONG).show()
            return
        }
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
            val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer = recognizer
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    voiceStatusMessage = "Listening… say one command"
                    voiceButton?.text = "Listening…"
                    updateStatus()
                }
                override fun onBeginningOfSpeech() {
                    voiceStatusMessage = "Hearing you…"
                    updateStatus()
                }
                override fun onRmsChanged(rmsdB: Float) { }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() {
                    voiceButton?.text = "Processing…"
                    voiceStatusMessage = "Processing voice command…"
                    updateStatus()
                }
                override fun onError(error: Int) {
                    voiceButton?.text = "🎙 Speak"
                    voiceStatusMessage = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "Microphone/audio error. Check phone microphone access."
                        SpeechRecognizer.ERROR_CLIENT -> "Speech service stopped. Tap Speak and try again."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission denied. Enable it in Android app settings."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition network error. Check internet or recognition-service settings."
                        SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that. Tap Speak and try again."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognition is busy. Wait a moment and try again."
                        SpeechRecognizer.ERROR_SERVER -> "Speech recognition service error. Try again."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected. Tap Speak and try again."
                        else -> "Speech recognition failed (error $error). Tap Speak to retry."
                    }
                    updateStatus()
                }
                override fun onResults(results: Bundle?) {
                    voiceButton?.text = "🎙 Speak"
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = matches?.firstOrNull()
                    if (spoken.isNullOrBlank()) {
                        voiceStatusMessage = "Didn't catch that. Tap Speak and try again."
                        updateStatus()
                    } else {
                        handleVoiceCommand(spoken)
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) { }
                override fun onEvent(eventType: Int, params: Bundle?) { }
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            voiceStatusMessage = "Starting voice recognition…"
            voiceButton?.text = "Listening…"
            updateStatus()
            recognizer.startListening(intent)
        } catch (ex: Exception) {
            speechRecognizer?.destroy()
            speechRecognizer = null
            voiceButton?.text = "🎙 Speak"
            voiceStatusMessage = "Couldn't start speech recognition: ${ex.javaClass.simpleName}. Check that a recognition service is enabled."
            updateStatus()
            Toast.makeText(this, "Couldn't start speech recognition", Toast.LENGTH_LONG).show()
        }
    }

    private fun handleVoiceCommand(spoken: String) {
        val command = spoken.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
        val result = when {
            command.contains("next song") || command == "next" || command.contains("skip song") || command == "skip" || command.contains("go next") || command == "next track" || command == "advance" -> {
                if (currentSongIndex < queue.lastIndex) { currentSongIndex++; playCurrent(); "Next song" }
                else { showHome("Queue finished."); "Queue finished" }
            }
            command.contains("previous song") || command.contains("last song") || command == "previous" || command == "back song" || command.contains("go back a song") || command == "previous track" || command == "go back" -> {
                if (currentSongIndex > 0) { currentSongIndex--; playCurrent(); "Previous song" }
                else { restartCurrentSong(); "Already at the first song — restarted" }
            }
            command.contains("pause") -> { paused = true; updateStatus(); "Paused" }
            command.contains("resume") || command.contains("continue") || command == "play" || command.contains("keep playing") || command.contains("start playing") -> { paused = false; lastTick = System.nanoTime(); updateStatus(); "Resumed" }
            command.contains("start over") || command.contains("restart") || command.contains("beginning") || command.contains("from the top") -> { restartCurrentSong(); "Restarted song" }
            command.contains("reset song settings") || command.contains("reset settings") -> { resetCurrentSongPlaybackSettings(); "Song settings reset to defaults" }
            command.contains("faster") || command.contains("speed up") -> { changeSpeed(1); "Speed increased" }
            command.contains("slower") || command.contains("slow down") -> { changeSpeed(-1); "Speed decreased" }
            command.contains("bigger text") || command.contains("larger text") || command.contains("font bigger") || command.contains("make text bigger") || command == "bigger" -> { changeFont(2f); "Text enlarged" }
            command.contains("smaller text") || command.contains("font smaller") || command.contains("make text smaller") || command == "smaller" -> { changeFont(-2f); "Text reduced" }
            command.contains("stop repeat") || command.contains("disable repeat") -> { repeatCurrentSong = false; updateStatus(); "Repeat disabled" }
            command.contains("repeat song") || command == "repeat" || command.contains("enable repeat") -> { repeatCurrentSong = true; updateStatus(); "Repeat enabled" }
            command == "stop" || command.contains("stop playback") -> { handler.removeCallbacks(tick); inViewer = false; showHome("Playback stopped."); "Playback stopped" }
            command.contains("what s next") || command.contains("what is next") || command.contains("next up") -> {
                val nextName = queue.getOrNull(currentSongIndex + 1)?.name
                voiceStatusMessage = if (nextName == null) "No next song in this set." else "Next song: $nextName"
                updateStatus()
                voiceStatusMessage ?: "No next song"
            }
            else -> { voiceStatusMessage = "Heard: ‘$spoken’ — command not recognized."; updateStatus(); "Command not recognized" }
        }
        if (inViewer) {
            voiceStatusMessage = "Heard: ‘$spoken’ → $result"
            updateStatus()
        }
    }

    private fun restartCurrentSong() {
        scrollAccumulator = 0.0
        endHandled = false
        scrollYFloat = (viewport?.height ?: 0).toFloat() + 20f
        scrollText?.translationY = scrollYFloat
        lastTick = System.nanoTime()
        updateStatus()
    }

    private fun rootFocusLyrics() {
        voiceButton?.clearFocus()
        performanceButton?.clearFocus()
        viewport?.requestFocus()
    }

    private fun songSettingsKey(song: Song): String {
        val encoded = android.util.Base64.encodeToString(song.uri.toString().toByteArray(Charsets.UTF_8), android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING)
        return "song_$encoded"
    }

    private fun loadSongPlaybackSettings(song: Song) {
        val key = songSettingsKey(song)
        val hasSaved = hasProFeatureAccess(ProFeature.PER_SONG_SETTINGS) &&
            songSettingsPrefs.contains("${key}_speed") && songSettingsPrefs.contains("${key}_font")
        if (hasSaved) {
            speedIndex = songSettingsPrefs.getInt("${key}_speed", 12).coerceIn(0, speedSteps.lastIndex)
            fontSp = songSettingsPrefs.getFloat("${key}_font", 32f).coerceIn(8f, 72f)
        } else {
            // Free users retain manual controls and shared starting defaults, but don't
            // load song-specific values. Pro users get each song's saved preferences.
            speedIndex = songSettingsPrefs.getInt("default_speed", 12).coerceIn(0, speedSteps.lastIndex)
            fontSp = songSettingsPrefs.getFloat("default_font", 32f).coerceIn(8f, 72f)
            if (hasProFeatureAccess(ProFeature.PER_SONG_SETTINGS)) saveCurrentSongPlaybackSettings()
        }
    }

    private fun saveCurrentSongPlaybackSettings() {
        val song = queue.getOrNull(currentSongIndex) ?: return
        val key = songSettingsKey(song)
        val editor = songSettingsPrefs.edit()
            .putInt("default_speed", speedIndex)
            .putFloat("default_font", fontSp)
        if (hasProFeatureAccess(ProFeature.PER_SONG_SETTINGS)) {
            editor.putInt("${key}_speed", speedIndex)
                .putFloat("${key}_font", fontSp)
        }
        editor.apply()
    }

    private fun changeSpeed(direction: Int) {
        speedIndex = (speedIndex + direction).coerceIn(0, speedSteps.lastIndex)
        saveCurrentSongPlaybackSettings()
        updateStatus()
    }

    private fun resetCurrentSongPlaybackSettings() {
        if (!hasProFeatureAccess(ProFeature.PER_SONG_SETTINGS)) {
            showProFeatureRequired("Per-song settings")
            return
        }
        val song = queue.getOrNull(currentSongIndex) ?: return
        val key = songSettingsKey(song)
        // Reset to the app's standard baseline and make that baseline the default for new songs.
        speedIndex = 12
        fontSp = 32f
        songSettingsPrefs.edit()
            .remove("${key}_speed").remove("${key}_font")
            .putInt("default_speed", speedIndex).putFloat("default_font", fontSp)
            .apply()
        saveCurrentSongPlaybackSettings()
        scrollText?.apply { setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp); requestLayout(); invalidate() }
        scrollText?.post { measureFullLyricsHeight() }
        updateStatus()
    }

    private fun changeFont(delta: Float) {
        fontSp = (fontSp + delta).coerceIn(8f, 72f)
        scrollText?.apply { setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp); requestLayout(); invalidate() }
        scrollText?.post { measureFullLyricsHeight() }
        saveCurrentSongPlaybackSettings()
        updateStatus()
    }

    private fun startIntermissionOrNext() {
        handler.removeCallbacks(tick)
        if (!inViewer) return
        if (currentSongIndex >= queue.lastIndex) {
            showHome("Queue finished.")
            return
        }
        if (queueDelaySeconds <= 0) {
            currentSongIndex++
            playCurrent()
            return
        }
        countdown = queueDelaySeconds
        showCountdown()
    }

    private fun showNextAfterManualBack() {
        handler.removeCallbacks(tick)
        if (currentSongIndex >= queue.lastIndex) {
            showHome("Queue finished.")
            return
        }
        // A manual BACK should show the same Next Up choices as a finished song,
        // even when the configured automatic delay is zero.
        countdown = queueDelaySeconds.coerceAtLeast(1)
        endHandled = true
        showCountdown()
    }

    private fun showCountdown() {
        handler.removeCallbacks(countdownTick)
        countdownGeneration++
        isCountdownScreen = true
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(36, 30, 36, 30)
            setBackgroundColor(Color.rgb(10, 14, 20)); isFocusable = false; isFocusableInTouchMode = false
        }
        val heading = makeText("NEXT UP", 26f, Color.rgb(255, 196, 0), true).apply { gravity = Gravity.CENTER }
        val next = makeText(queue.getOrNull(currentSongIndex + 1)?.name ?: "", 30f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        val counter = makeText("Starting in $countdown seconds", 26f, Color.LTGRAY).apply { gravity = Gravity.CENTER }
        root.addView(heading, LinearLayout.LayoutParams(-1, 64))
        root.addView(next, LinearLayout.LayoutParams(-1, 80))
        root.addView(counter, LinearLayout.LayoutParams(-1, 64))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        var firstActionButton: Button? = null
        fun addAction(label: String, action: () -> Unit) {
            val b = Button(this).apply {
                text = label
                styleButton(this)
                setOnClickListener {
                    // Stop and invalidate the timer before running the chosen action.
                    handler.removeCallbacks(countdownTick)
                    countdownGeneration++
                    isCountdownScreen = false
                    action()
                }
            }
            if (firstActionButton == null) firstActionButton = b
            b.minHeight = responsiveDp(76, 58)
            b.setPadding(24, 18, 24, 18)
            row.addView(b, LinearLayout.LayoutParams(0, 84, 1f).apply { setMargins(8, 8, 8, 8) })
        }
        addAction("Start now") {
            // Start the song currently shown on the countdown screen, and make
            // sure an old timer cannot advance the queue again a second later.
            currentSongIndex++
            playCurrent()
        }
        addAction("Skip file") {
            // Skip only the song currently shown as NEXT UP. Do not auto-play
            // the following song: show its own countdown and choices instead.
            currentSongIndex++
            if (currentSongIndex >= queue.lastIndex) {
                showHome("Queue finished. Last queued song was skipped.")
            } else {
                countdown = queueDelaySeconds
                showCountdown()
            }
        }
        addAction("Cancel queue") { showHome("Queue cancelled.") }
        root.addView(row, LinearLayout.LayoutParams(-1, 104))
        setContentView(root)
        remoteNavigationRoot = root
        // Give the TV remote a real, visible starting focus. DPAD navigation can
        // then move between all three actions and the yellow focus style is shown.
        firstActionButton?.post { firstActionButton?.requestFocus() }
        handler.removeCallbacks(countdownTick)
        handler.postDelayed(countdownTick, 1000)
        countdownView = counter
    }

    private var countdownView: TextView? = null
    private val countdownTick = object : Runnable {
        override fun run() {
            // A button press or a replacement countdown cancels this run.
            if (!isCountdownScreen) return
            countdown--
            if (countdown <= 0) {
                isCountdownScreen = false
                currentSongIndex++
                playCurrent()
            } else {
                countdownView?.text = "Starting in $countdown seconds"
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (inViewer && keyCode in listOf(KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER) &&
            voiceButton?.hasFocus() != true && performanceButton?.hasFocus() != true && okPressPending) {
            handler.removeCallbacks(okLongPressRunnable)
            okPressPending = false
            if (!okLongPressTriggered) {
                paused = !paused
                updateStatus()
            }
            okLongPressTriggered = false
            return true
        }
        if (keyCode in listOf(KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER)) {
            // A long press has already launched voice recognition; swallow key-up so
            // Android cannot also activate a focused footer button.
            if (okLongPressTriggered) {
                okLongPressTriggered = false
                return true
            }
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Handle BACK here before Android's default activity navigation can
        // route it away from the lyrics viewer. This makes multi-song BACK
        // behave exactly like finishing the current song.
        if (keyCode == KeyEvent.KEYCODE_BACK && event?.repeatCount == 0) {
            handler.removeCallbacks(okLongPressRunnable)
            okPressPending = false
            okLongPressTriggered = false
            if (inViewer) {
                val footerHasFocus = voiceButton?.hasFocus() == true || performanceButton?.hasFocus() == true
                if (footerHasFocus) {
                    // BACK is the explicit exit from footer navigation to lyric controls.
                    rootFocusLyrics()
                    return true
                }
                // From the lyrics area, preserve normal BACK behavior (next-song flow
                // for a setlist, or return to file selection for a single song).
            } else {
                onBackPressed()
                return true
            }
        }
        if (isCountdownScreen) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_MENU) {
                handler.removeCallbacks(countdownTick)
                showHome("Queue cancelled.")
                return true
            }
            // Let Android's normal focus system move the yellow highlight between
            // Start now, Skip file and Cancel queue instead of treating DPAD as
            // teleprompter speed/font controls.
            return super.onKeyDown(keyCode, event)
        }
        if (!inViewer) return super.onKeyDown(keyCode, event)

        // On the lyrics area, a short OK toggles pause/resume; holding OK for
        // about one second invokes push-to-talk without moving focus to the footer.
        // Footer buttons retain their normal click behavior when they have focus.
        val footerHasFocus = voiceButton?.hasFocus() == true || performanceButton?.hasFocus() == true
        if (!footerHasFocus && keyCode in listOf(KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER)) {
            if (event?.repeatCount == 0 && !okPressPending) {
                okLongPressTriggered = false
                okPressPending = true
                handler.removeCallbacks(okLongPressRunnable)
                handler.postDelayed(okLongPressRunnable, 900L)
            }
            return true
        }

        // The lyrics viewer normally maps the D-pad to teleprompter controls. Let
        // users reach the in-app microphone without a touch screen: the first UP
        // moves focus to Speak, and OK/Enter activates its click listener.
        val micHadFocus = voiceButton?.hasFocus() == true
        val modeHadFocus = performanceButton?.hasFocus() == true
        if ((micHadFocus || modeHadFocus) && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) {
            return super.onKeyDown(keyCode, event)
        }
        // Once the long-OK shortcut opens the footer, DOWN moves from Speak to
        // Performance. BACK returns to lyric controls; UP/DOWN there adjust font.
        if (micHadFocus && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
            performanceButton?.requestFocus()
            return true
        }
        if ((micHadFocus || modeHadFocus) && keyCode == KeyEvent.KEYCODE_DPAD_UP) {
            rootFocusLyrics()
            changeFont(2f)
            return true
        }
        if (modeHadFocus && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
            rootFocusLyrics()
            changeFont(-2f)
            return true
        }
        if ((micHadFocus || modeHadFocus) && keyCode in listOf(
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT
            )) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) { changeSpeed(1); return true }
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) { changeSpeed(-1); return true }
        }
        if (!micHadFocus && !modeHadFocus && keyCode == KeyEvent.KEYCODE_DPAD_UP) {
            changeFont(2f)
            return true
        }
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                paused = !paused; updateStatus(); return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_PLUS, KeyEvent.KEYCODE_EQUALS -> {
                changeSpeed(1); return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MINUS -> {
                changeSpeed(-1); return true
            }
            KeyEvent.KEYCODE_DPAD_UP -> { changeFont(2f); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { changeFont(-2f); return true }
            KeyEvent.KEYCODE_R -> { restartCurrentSong(); return true }
            KeyEvent.KEYCODE_BACK -> {
                handler.removeCallbacks(tick)
                if (queue.size > 1) {
                    // Treat Back during a multi-song set as if this song finished:
                    // show the normal intermission/countdown and its action buttons.
                    showNextAfterManualBack()
                } else {
                    // A single selected lyric file returns to file selection, not Home.
                    inViewer = false
                    showFileBrowser()
                }
                return true
            }
            KeyEvent.KEYCODE_MENU -> {
                handler.removeCallbacks(tick)
                inViewer = false
                showHome("Playback stopped.")
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        updateBlinker?.let { handler.removeCallbacks(it) }
        updateBlinker = null
        updateAvailableButton = null
        stopPhoneRemoteServer()
        handler.removeCallbacks(tick)
        handler.removeCallbacks(countdownTick)
        handler.removeCallbacks(okLongPressRunnable)
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) { }
        speechRecognizer = null
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (isCountdownScreen) {
            handler.removeCallbacks(countdownTick)
            showHome("Queue cancelled.")
        } else if (inViewer) {
            handler.removeCallbacks(tick)
            if (queue.size > 1) {
                showNextAfterManualBack()
            } else {
                inViewer = false
                showFileBrowser()
            }
        } else if (inOnlineLyrics) {
            // BACK always exits the online area. Folder navigation remains available
            // through the explicit Parent folder row, so users can never get trapped.
            inOnlineLyrics = false
            onlineRootUrl = null
            onlineCurrentPath = ""
            showFileBrowser()
        } else if (inRecentHistory || inSavedSetlists || inBrowser) {
            showHome()
        } else {
            val now = System.currentTimeMillis()
            if (now - lastBackPressAt < 2200L) finish() else {
                lastBackPressAt = now
                Toast.makeText(this, "Press BACK again to exit Gig Assistant", Toast.LENGTH_LONG).show()
            }
        }
    }

    companion object {
        private const val REQUEST_FILES = 1001
        private const val REQUEST_STORAGE_PERMISSION = 1002
        private const val REQUEST_MIC_PERMISSION = 1003
        private const val REQUEST_VOICE_RECOGNITION = 1004
    }
}

