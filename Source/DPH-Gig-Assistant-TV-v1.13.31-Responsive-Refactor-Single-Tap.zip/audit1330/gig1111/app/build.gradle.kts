plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gravelunion.gigassistanttv"
    compileSdk = 35

    // Keep Java and Kotlin bytecode targets aligned for Android builds.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        applicationId = "com.gravelunion.gigassistanttv"
        minSdk = 23
        targetSdk = 28
        versionCode = 97
        versionName = "1.13.31"
    }
}


dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
